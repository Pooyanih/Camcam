package com.reactioncam.app.settings

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.util.Log

/**
 * Best-effort routing of the recording's audio input to a specific physical device.
 * CameraX's Recorder always captures from whatever the system currently treats as the
 * active input — there's no per-recording "use this AudioDeviceInfo" parameter — so
 * the approach here is to ask Android to make the chosen device the active input
 * (AudioManager.setCommunicationDevice on Android 12+, the older Bluetooth SCO calls
 * below that) right before recording starts, then release that request when done.
 *
 * This is the one part of the app I'm least able to verify without real devices
 * connected (a Bluetooth headset, a USB mic) — if a specific input doesn't actually
 * get used on some device, the recording still proceeds on the phone's default mic
 * rather than failing, since every call here is wrapped defensively.
 */
object AudioInputHelper {
    private const val TAG = "AudioInputHelper"

    fun availableInputs(context: Context): List<MicSource> {
        val result = linkedSetOf(MicSource.DEFAULT)
        try {
            val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val devices = am.getDevices(AudioManager.GET_DEVICES_INPUTS)
            for (d in devices) {
                when (d.type) {
                    AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> result.add(MicSource.BLUETOOTH)
                    AudioDeviceInfo.TYPE_WIRED_HEADSET -> result.add(MicSource.WIRED)
                    AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET -> result.add(MicSource.USB)
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Could not enumerate audio inputs, only Default will be offered", e)
        }
        return result.toList()
    }

    /** Call right before starting the camera recording. Returns true if the requested input was actually applied. */
    fun start(context: Context, micSource: MicSource): Boolean {
        if (micSource == MicSource.DEFAULT) return true
        return try {
            val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val targetTypes = when (micSource) {
                    MicSource.BLUETOOTH -> setOf(AudioDeviceInfo.TYPE_BLUETOOTH_SCO)
                    MicSource.WIRED -> setOf(AudioDeviceInfo.TYPE_WIRED_HEADSET)
                    MicSource.USB -> setOf(AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET)
                    else -> emptySet()
                }
                val device = am.availableCommunicationDevices.firstOrNull { it.type in targetTypes }
                if (device != null) am.setCommunicationDevice(device) else false
            } else if (micSource == MicSource.BLUETOOTH) {
                @Suppress("DEPRECATION")
                am.startBluetoothSco()
                @Suppress("DEPRECATION")
                am.isBluetoothScoOn = true
                true
            } else {
                // Wired/USB mics are typically picked up automatically by the platform
                // once plugged in on older Android versions; nothing more to force here.
                false
            }
        } catch (e: Exception) {
            Log.w(TAG, "Could not route audio to $micSource, using the default mic instead", e)
            false
        }
    }

    /** Call after the recording stops, to release whatever routing [start] requested. */
    fun stop(context: Context, micSource: MicSource) {
        if (micSource == MicSource.DEFAULT) return
        try {
            val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                am.clearCommunicationDevice()
            } else if (micSource == MicSource.BLUETOOTH) {
                @Suppress("DEPRECATION")
                am.isBluetoothScoOn = false
                @Suppress("DEPRECATION")
                am.stopBluetoothSco()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error releasing audio routing for $micSource", e)
        }
    }
}
