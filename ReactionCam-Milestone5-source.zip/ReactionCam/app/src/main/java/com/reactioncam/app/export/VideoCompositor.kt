package com.reactioncam.app.export

import android.content.Context
import android.graphics.Color
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import com.reactioncam.app.settings.SettingsRepository
import java.io.File

/**
 * Renders the final reaction video: camera take as the full-screen main layer
 * (cropped to the chosen aspect ratio), source video as a picture-in-picture overlay
 * positioned per [pipRectNormalized] with rounded corners/border per settings, frozen
 * or relocated per [timeline] for every pause/rewind/fast-forward. Resolution, frame
 * rate, bitrate, codec and aspect ratio are all read live from [SettingsRepository]
 * and genuinely applied here — this is the one part of the pipeline built on raw
 * MediaCodec, so every Quality & Format setting takes real effect on the file you
 * actually get, regardless of what the intermediate camera capture used.
 *
 * Runs entirely offline (not real-time), so there's no risk of dropped frames under
 * load — it's exactly as fast as the device's hardware codecs allow.
 */
class VideoCompositor(
    private val context: Context,
    private val cameraTakeFile: File,
    private val sourceVideoUri: Uri,
    private val pipRectNormalized: FloatArray, // x, y, w, h as fractions of the canvas
    private val timeline: PlaybackTimeline,
    private val outputFile: File,
    private val onProgress: (Float) -> Unit
) {
    fun run() {
        val mainExtractor = MediaExtractor().apply { setDataSource(cameraTakeFile.absolutePath) }
        val overlayExtractor = MediaExtractor().apply {
            context.contentResolver.openFileDescriptor(sourceVideoUri, "r")?.use { pfd ->
                setDataSource(pfd.fileDescriptor)
            } ?: error("Could not open source video")
        }

        val mainVideoTrack = findTrack(mainExtractor, "video/") ?: error("No video track in camera take")
        val overlayVideoTrack = findTrack(overlayExtractor, "video/") ?: error("No video track in source video")

        val mainFormat = mainExtractor.getTrackFormat(mainVideoTrack)
        val overlayFormat = overlayExtractor.getTrackFormat(overlayVideoTrack)

        val mainRotation = readRotationDegrees(cameraTakeFile.absolutePath, null)
        val overlayRotation = readRotationDegrees(null, sourceVideoUri)

        val mainRawW = mainFormat.getInteger(MediaFormat.KEY_WIDTH)
        val mainRawH = mainFormat.getInteger(MediaFormat.KEY_HEIGHT)
        val mainCapturedW = if (mainRotation == 90 || mainRotation == 270) mainRawH else mainRawW
        val mainCapturedH = if (mainRotation == 90 || mainRotation == 270) mainRawW else mainRawH
        val mainCapturedAspect = mainCapturedW.toFloat() / mainCapturedH.toFloat()

        val overlayRawW = overlayFormat.getInteger(MediaFormat.KEY_WIDTH)
        val overlayRawH = overlayFormat.getInteger(MediaFormat.KEY_HEIGHT)
        val overlayW = if (overlayRotation == 90 || overlayRotation == 270) overlayRawH else overlayRawW
        val overlayH = if (overlayRotation == 90 || overlayRotation == 270) overlayRawW else overlayRawH
        val overlayAspect = overlayW.toFloat() / overlayH.toFloat()

        val durationUs = if (mainFormat.containsKey(MediaFormat.KEY_DURATION)) {
            mainFormat.getLong(MediaFormat.KEY_DURATION)
        } else 1L
        val durationMs = durationUs / 1000

        // --- Quality & Format settings, applied for real since this is our own MediaCodec pipeline ---
        val resolutionSetting = SettingsRepository.resolution
        val aspectSetting = SettingsRepository.aspectRatio
        val (canvasWidth, canvasHeight) = computeCanvasSize(resolutionSetting.refWidth, resolutionSetting.refHeight, aspectSetting.wRatio, aspectSetting.hRatio)
        val canvasAspect = canvasWidth.toFloat() / canvasHeight.toFloat()

        val requestedMime = SettingsRepository.codec.mimeType
        val encoderMime = resolveEncoderMime(requestedMime)
        val bitrateBps = (SettingsRepository.bitrateMbps * 1_000_000).coerceAtLeast(500_000)
        val targetFps = SettingsRepository.frameRate.coerceIn(1, 120)
        val frameDurationUs = 1_000_000L / targetFps

        val cornerRadiusFraction = (SettingsRepository.pipCornerRadiusDp / 80f).coerceIn(0f, 0.5f)
        val borderEnabled = SettingsRepository.pipBorderEnabled
        val borderColor = hexToRgbaFloats(SettingsRepository.theme.accent)

        // --- Audio: decode + mix + re-encode mic and source sound together, up front ---
        val audioResult = AudioMixer.mixAndEncode(context, cameraTakeFile, sourceVideoUri, timeline, durationMs)

        // --- Encoder setup ---
        val outputFormat = MediaFormat.createVideoFormat(encoderMime, canvasWidth, canvasHeight).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, bitrateBps)
            setInteger(MediaFormat.KEY_FRAME_RATE, targetFps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
        }
        val encoder = MediaCodec.createEncoderByType(encoderMime)
        encoder.configure(outputFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val encoderInputSurface = encoder.createInputSurface()
        encoder.start()

        val eglSurface = EncoderEglSurface(encoderInputSurface)
        eglSurface.setup()

        val quadProgram = OesQuadProgram()
        quadProgram.setup()

        val mainTexture = FrameTexture()
        val overlayTexture = FrameTexture()

        val mainDecoder = VideoTrackDecoder(mainExtractor, mainVideoTrack, mainTexture.surface)
        val overlayDecoder = VideoTrackDecoder(overlayExtractor, overlayVideoTrack, overlayTexture.surface)

        val muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var muxerVideoTrack = -1
        var muxerAudioTrack = -1
        var muxerStarted = false
        val bufferInfo = MediaCodec.BufferInfo()

        fun startMuxerAndFlushAudio() {
            muxerVideoTrack = muxer.addTrack(encoder.outputFormat)
            if (audioResult != null) {
                muxerAudioTrack = muxer.addTrack(audioResult.first)
            }
            muxer.start()
            muxerStarted = true
            audioResult?.second?.forEach { (bytes, info) ->
                muxer.writeSampleData(muxerAudioTrack, java.nio.ByteBuffer.wrap(bytes), info)
            }
        }

        fun drainEncoder(endOfStream: Boolean) {
            if (endOfStream) encoder.signalEndOfInputStream()
            while (true) {
                val outIdx = encoder.dequeueOutputBuffer(bufferInfo, if (endOfStream) 10_000 else 0)
                when {
                    outIdx == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                        if (!endOfStream) return
                    }
                    outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        check(!muxerStarted) { "Encoder format changed twice" }
                        startMuxerAndFlushAudio()
                    }
                    outIdx >= 0 -> {
                        val encodedData = encoder.getOutputBuffer(outIdx)
                        if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) {
                            bufferInfo.size = 0
                        }
                        if (bufferInfo.size != 0 && encodedData != null && muxerStarted) {
                            encodedData.position(bufferInfo.offset)
                            encodedData.limit(bufferInfo.offset + bufferInfo.size)
                            muxer.writeSampleData(muxerVideoTrack, encodedData, bufferInfo)
                        }
                        val isEos = bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                        encoder.releaseOutputBuffer(outIdx, false)
                        if (isEos) return
                    }
                }
            }
        }

        // --- Main render loop: paced by the TARGET frame rate (not necessarily the
        // capture's own rate), so the Quality & Format frame-rate setting genuinely
        // changes the output frame count instead of just being a metadata hint. ---
        var outputFrameIndex = 0L
        while (true) {
            val outputPtsUs = outputFrameIndex * frameDurationUs
            eglSurface.makeCurrent()

            if (!mainDecoder.outputEos) {
                mainDecoder.advanceTo(outputPtsUs, mainTexture)
            }
            if (mainDecoder.lastRenderedPtsUs < 0) {
                if (mainDecoder.outputEos) break
                outputFrameIndex++
                continue
            }
            if (mainDecoder.outputEos && mainDecoder.lastRenderedPtsUs < outputPtsUs) {
                break // camera take genuinely ended before this output tick
            }

            val sourceVirtualMs = timeline.mapToSourceTimeMs(outputPtsUs / 1000)
            if (!overlayDecoder.outputEos) {
                overlayDecoder.advanceTo(sourceVirtualMs * 1000, overlayTexture)
            }

            // Main layer: full canvas, cropped to the chosen aspect ratio if it
            // doesn't match what the camera actually captured.
            val mainMatrix = buildTexMatrix(
                mainTexture.getTransformMatrix(), mainRotation, applyCrop = true,
                srcAspect = mainCapturedAspect, dstAspect = canvasAspect
            )
            quadProgram.draw(mainTexture.textureId, mainMatrix, 0, 0, canvasWidth, canvasHeight)

            // Overlay (PiP) layer: center-cropped into its rect, with rounded corners/border.
            val pipX = (pipRectNormalized[0] * canvasWidth).toInt()
            val pipYTop = (pipRectNormalized[1] * canvasHeight).toInt()
            val pipW = (pipRectNormalized[2] * canvasWidth).toInt().coerceAtLeast(2)
            val pipH = (pipRectNormalized[3] * canvasHeight).toInt().coerceAtLeast(2)
            // GL viewport origin is bottom-left; our rect was captured top-left-origin.
            val pipYGl = canvasHeight - pipYTop - pipH

            val overlayMatrix = buildTexMatrix(
                overlayTexture.getTransformMatrix(), overlayRotation, applyCrop = true,
                srcAspect = overlayAspect, dstAspect = pipW.toFloat() / pipH
            )
            val cornerRadiusPx = cornerRadiusFraction * minOf(pipW, pipH).toFloat()
            val borderWidthPx = if (borderEnabled) (3f / 300f) * minOf(pipW, pipH) else 0f
            quadProgram.draw(
                overlayTexture.textureId, overlayMatrix, pipX, pipYGl, pipW, pipH,
                applyRounding = true,
                cornerRadiusPx = cornerRadiusPx,
                borderWidthPx = borderWidthPx,
                borderColor = borderColor
            )

            eglSurface.setPresentationTimeNs(outputPtsUs * 1000)
            eglSurface.swapBuffers()

            drainEncoder(endOfStream = false)
            onProgress((outputPtsUs.toFloat() / durationUs.toFloat()).coerceIn(0f, 1f))
            outputFrameIndex++
        }

        drainEncoder(endOfStream = true)

        muxer.stop()
        muxer.release()
        encoder.stop()
        encoder.release()
        mainDecoder.release()
        overlayDecoder.release()
        mainTexture.release()
        overlayTexture.release()
        eglSurface.release()
        mainExtractor.release()
        overlayExtractor.release()
        onProgress(1f)
    }

    /** Falls back to H.264 if the device can't create an encoder for the requested mime (e.g. no HEVC encoder). */
    private fun resolveEncoderMime(preferredMime: String): String {
        return try {
            val codec = MediaCodec.createEncoderByType(preferredMime)
            codec.release()
            preferredMime
        } catch (e: Exception) {
            MediaFormat.MIMETYPE_VIDEO_AVC
        }
    }

    /** Combines the resolution tier's long edge with the chosen aspect ratio into concrete, even pixel dimensions. */
    private fun computeCanvasSize(refWidth: Int, refHeight: Int, aspectW: Int, aspectH: Int): Pair<Int, Int> {
        val longEdge = maxOf(refWidth, refHeight)
        fun evenize(v: Int) = if (v % 2 == 0) v else v + 1
        return if (aspectW >= aspectH) {
            val w = evenize(longEdge)
            val h = evenize((longEdge.toFloat() * aspectH / aspectW).toInt())
            w to h
        } else {
            val h = evenize(longEdge)
            val w = evenize((longEdge.toFloat() * aspectW / aspectH).toInt())
            w to h
        }
    }

    private fun hexToRgbaFloats(hex: String): FloatArray {
        val c = Color.parseColor(hex)
        return floatArrayOf(Color.red(c) / 255f, Color.green(c) / 255f, Color.blue(c) / 255f, 1f)
    }

    private fun findTrack(extractor: MediaExtractor, mimePrefix: String): Int? {
        for (i in 0 until extractor.trackCount) {
            val mime = extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith(mimePrefix)) return i
        }
        return null
    }

    private fun readRotationDegrees(path: String?, uri: Uri?): Int {
        val retriever = MediaMetadataRetriever()
        return try {
            if (path != null) retriever.setDataSource(path) else retriever.setDataSource(context, uri!!)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
        } catch (_: Exception) {
            0
        } finally {
            retriever.release()
        }
    }
}
