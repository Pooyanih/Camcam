package com.reactioncam.app.export

import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.Matrix
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

/**
 * Minimal EGL/GLES helper for offscreen->encoder rendering. This is the same pattern
 * used by Android's Grafika samples for "continuous capture" style video processing:
 * an EGL surface wraps a MediaCodec encoder's input Surface, and every eglSwapBuffers
 * call submits one encoded frame.
 */
class EncoderEglSurface(private val encoderInputSurface: Surface) {
    private var eglDisplay: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var eglContext: EGLContext = EGL14.EGL_NO_CONTEXT
    private var eglSurface: EGLSurface = EGL14.EGL_NO_SURFACE

    fun setup() {
        eglDisplay = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        if (eglDisplay == EGL14.EGL_NO_DISPLAY) error("eglGetDisplay failed")
        val version = IntArray(2)
        if (!EGL14.eglInitialize(eglDisplay, version, 0, version, 1)) error("eglInitialize failed")

        val attribList = intArrayOf(
            EGL14.EGL_RED_SIZE, 8,
            EGL14.EGL_GREEN_SIZE, 8,
            EGL14.EGL_BLUE_SIZE, 8,
            EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            0x3142, 1, // EGL_RECORDABLE_ANDROID
            EGL14.EGL_NONE
        )
        val configs = arrayOfNulls<EGLConfig>(1)
        val numConfigs = IntArray(1)
        EGL14.eglChooseConfig(eglDisplay, attribList, 0, configs, 0, 1, numConfigs, 0)
        val config = configs[0] ?: error("eglChooseConfig failed")

        val contextAttribs = intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE)
        eglContext = EGL14.eglCreateContext(eglDisplay, config, EGL14.EGL_NO_CONTEXT, contextAttribs, 0)

        val surfaceAttribs = intArrayOf(EGL14.EGL_NONE)
        eglSurface = EGL14.eglCreateWindowSurface(eglDisplay, config, encoderInputSurface, surfaceAttribs, 0)

        makeCurrent()
    }

    fun makeCurrent() {
        EGL14.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext)
    }

    fun setPresentationTimeNs(ns: Long) {
        android.opengl.EGLExt.eglPresentationTimeANDROID(eglDisplay, eglSurface, ns)
    }

    fun swapBuffers() {
        EGL14.eglSwapBuffers(eglDisplay, eglSurface)
    }

    fun release() {
        if (eglDisplay != EGL14.EGL_NO_DISPLAY) {
            EGL14.eglMakeCurrent(eglDisplay, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            EGL14.eglDestroySurface(eglDisplay, eglSurface)
            EGL14.eglDestroyContext(eglDisplay, eglContext)
            EGL14.eglTerminate(eglDisplay)
        }
        eglDisplay = EGL14.EGL_NO_DISPLAY
        eglContext = EGL14.EGL_NO_CONTEXT
        eglSurface = EGL14.EGL_NO_SURFACE
    }
}

/** Allocates a GL_TEXTURE_EXTERNAL_OES texture, as required for MediaCodec/SurfaceTexture output. */
fun createExternalOesTexture(): Int {
    val textures = IntArray(1)
    GLES20.glGenTextures(1, textures, 0)
    val texId = textures[0]
    GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texId)
    GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
    GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
    GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
    GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
    return texId
}

/**
 * Shader program that draws a full quad sampling from a GL_TEXTURE_EXTERNAL_OES
 * texture, with a 4x4 texture matrix (SurfaceTexture's own transform combined with an
 * optional center-crop, for center-cropping the PiP overlay into its box) and a
 * viewport rect controlling where on the canvas it lands.
 */
class OesQuadProgram {
    private var program = 0
    private var aPositionLoc = 0
    private var aTexCoordLoc = 0
    private var uTexMatrixLoc = 0
    private var uRectSizeLoc = 0
    private var uCornerRadiusLoc = 0
    private var uBorderWidthLoc = 0
    private var uBorderColorLoc = 0
    private var uApplyRoundingLoc = 0

    private val quadVertices = floatArrayOf(
        -1f, -1f,
        1f, -1f,
        -1f, 1f,
        1f, 1f
    )
    private val quadTexCoords = floatArrayOf(
        0f, 0f,
        1f, 0f,
        0f, 1f,
        1f, 1f
    )
    private val vertexBuffer: FloatBuffer = toFloatBuffer(quadVertices)
    private val texCoordBuffer: FloatBuffer = toFloatBuffer(quadTexCoords)

    private val vertexShaderSrc = """
        attribute vec4 aPosition;
        attribute vec4 aTexCoord;
        uniform mat4 uTexMatrix;
        varying vec2 vTexCoord;
        varying vec2 vLocalPos;
        void main() {
            gl_Position = aPosition;
            vTexCoord = (uTexMatrix * aTexCoord).xy;
            vLocalPos = (aPosition.xy + 1.0) / 2.0;
        }
    """.trimIndent()

    // vLocalPos is the fragment's position within the destination rect (0..1,
    // independent of any texture rotation/crop), used purely for the rounded-rect
    // mask/border so corner radius applies to the *shape on screen*, not the source
    // image's own orientation.
    private val fragmentShaderSrc = """
        #extension GL_OES_EGL_image_external : require
        precision mediump float;
        varying vec2 vTexCoord;
        varying vec2 vLocalPos;
        uniform samplerExternalOES uTexture;
        uniform vec2 uRectSize;
        uniform float uCornerRadius;
        uniform float uBorderWidth;
        uniform vec4 uBorderColor;
        uniform float uApplyRounding;

        float roundedBoxSDF(vec2 p, vec2 halfSize, float r) {
            vec2 q = abs(p) - halfSize + r;
            return length(max(q, 0.0)) - r;
        }

        void main() {
            vec4 color = texture2D(uTexture, vTexCoord);
            if (uApplyRounding > 0.5) {
                vec2 centerPos = (vLocalPos - 0.5) * uRectSize;
                float dist = roundedBoxSDF(centerPos, uRectSize * 0.5, uCornerRadius);
                if (dist > 0.0) {
                    discard;
                }
                if (uBorderWidth > 0.0 && dist > -uBorderWidth) {
                    color = uBorderColor;
                }
            }
            gl_FragColor = color;
        }
    """.trimIndent()

    fun setup() {
        val vs = compileShader(GLES20.GL_VERTEX_SHADER, vertexShaderSrc)
        val fs = compileShader(GLES20.GL_FRAGMENT_SHADER, fragmentShaderSrc)
        program = GLES20.glCreateProgram().also {
            GLES20.glAttachShader(it, vs)
            GLES20.glAttachShader(it, fs)
            GLES20.glLinkProgram(it)
        }
        aPositionLoc = GLES20.glGetAttribLocation(program, "aPosition")
        aTexCoordLoc = GLES20.glGetAttribLocation(program, "aTexCoord")
        uTexMatrixLoc = GLES20.glGetUniformLocation(program, "uTexMatrix")
        uRectSizeLoc = GLES20.glGetUniformLocation(program, "uRectSize")
        uCornerRadiusLoc = GLES20.glGetUniformLocation(program, "uCornerRadius")
        uBorderWidthLoc = GLES20.glGetUniformLocation(program, "uBorderWidth")
        uBorderColorLoc = GLES20.glGetUniformLocation(program, "uBorderColor")
        uApplyRoundingLoc = GLES20.glGetUniformLocation(program, "uApplyRounding")
    }

    /**
     * Draws [textureId] into the sub-rectangle [vx],[vy],[vw],[vh] (pixels, origin
     * bottom-left, matching GL viewport convention) of the currently bound surface.
     * [cornerRadiusPx]/[borderWidthPx]/[borderColor] only take effect when
     * [applyRounding] is true (used for the PIP overlay, not the full-screen main layer).
     */
    fun draw(
        textureId: Int,
        texMatrix: FloatArray,
        vx: Int, vy: Int, vw: Int, vh: Int,
        applyRounding: Boolean = false,
        cornerRadiusPx: Float = 0f,
        borderWidthPx: Float = 0f,
        borderColor: FloatArray = floatArrayOf(1f, 1f, 1f, 1f)
    ) {
        GLES20.glViewport(vx, vy, vw, vh)
        GLES20.glUseProgram(program)

        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, textureId)
        GLES20.glUniform1i(GLES20.glGetUniformLocation(program, "uTexture"), 0)
        GLES20.glUniformMatrix4fv(uTexMatrixLoc, 1, false, texMatrix, 0)
        GLES20.glUniform2f(uRectSizeLoc, vw.toFloat(), vh.toFloat())
        GLES20.glUniform1f(uCornerRadiusLoc, cornerRadiusPx)
        GLES20.glUniform1f(uBorderWidthLoc, borderWidthPx)
        GLES20.glUniform4fv(uBorderColorLoc, 1, borderColor, 0)
        GLES20.glUniform1f(uApplyRoundingLoc, if (applyRounding) 1f else 0f)

        vertexBuffer.position(0)
        GLES20.glEnableVertexAttribArray(aPositionLoc)
        GLES20.glVertexAttribPointer(aPositionLoc, 2, GLES20.GL_FLOAT, false, 0, vertexBuffer)

        texCoordBuffer.position(0)
        GLES20.glEnableVertexAttribArray(aTexCoordLoc)
        GLES20.glVertexAttribPointer(aTexCoordLoc, 2, GLES20.GL_FLOAT, false, 0, texCoordBuffer)

        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)

        GLES20.glDisableVertexAttribArray(aPositionLoc)
        GLES20.glDisableVertexAttribArray(aTexCoordLoc)
    }

    private fun compileShader(type: Int, src: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, src)
        GLES20.glCompileShader(shader)
        val status = IntArray(1)
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, status, 0)
        if (status[0] == 0) {
            val log = GLES20.glGetShaderInfoLog(shader)
            GLES20.glDeleteShader(shader)
            error("Shader compile failed: $log")
        }
        return shader
    }

    private fun toFloatBuffer(arr: FloatArray): FloatBuffer {
        return ByteBuffer.allocateDirect(arr.size * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
            .apply { put(arr); position(0) }
    }
}

/**
 * Builds the final texture matrix applied to a decoded video frame before sampling:
 * SurfaceTexture's own transform (required for correct orientation on every device),
 * a rotation to compensate for the track's recorded-orientation metadata (portrait
 * captures are usually stored landscape-dimensioned with a rotation hint), and an
 * optional center-crop so [srcAspect] (post-rotation) fills [dstAspect] without
 * stretching.
 *
 * Note: the sign of the rotation compensation is the one common convention for
 * MediaMetadataRetriever's rotation-degrees value; if a captured video ever appears
 * sideways/mirrored on a specific device, flip the sign passed for [rotationDegrees]
 * at the call site — this couldn't be verified against real hardware in the build
 * environment this project was authored in.
 */
fun buildTexMatrix(
    stMatrix: FloatArray,
    rotationDegrees: Int,
    applyCrop: Boolean,
    srcAspect: Float,
    dstAspect: Float
): FloatArray {
    val m = FloatArray(16)
    Matrix.setIdentityM(m, 0)
    Matrix.translateM(m, 0, 0.5f, 0.5f, 0f)
    if (rotationDegrees != 0) {
        Matrix.rotateM(m, 0, rotationDegrees.toFloat(), 0f, 0f, 1f)
    }
    if (applyCrop) {
        if (dstAspect > srcAspect) {
            Matrix.scaleM(m, 0, 1f, srcAspect / dstAspect, 1f)
        } else {
            Matrix.scaleM(m, 0, dstAspect / srcAspect, 1f, 1f)
        }
    }
    Matrix.translateM(m, 0, -0.5f, -0.5f, 0f)
    val result = FloatArray(16)
    Matrix.multiplyMM(result, 0, m, 0, stMatrix, 0)
    return result
}
