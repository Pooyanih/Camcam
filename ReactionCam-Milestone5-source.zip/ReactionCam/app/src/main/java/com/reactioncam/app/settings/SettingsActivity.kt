package com.reactioncam.app.settings

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.reactioncam.app.R
import java.util.Locale

/**
 * Settings screen covering Milestone 2's two feature groups: Quality & Format
 * (resolution, frame rate, bitrate, codec, aspect ratio, live size estimate) and
 * Look & Layout (theme, PIP corner roundness/border, reset remembered layout).
 * Every control here writes straight through to [SettingsRepository]; there's no
 * separate "Save" step other than the account-wide "Done" button, so a setting takes
 * effect the moment you change it (the estimate updates live; other screens pick the
 * new values up next time they read the repository).
 */
class SettingsActivity : AppCompatActivity() {

    private lateinit var tvSizeEstimate: TextView
    private lateinit var tvBitrateLabel: TextView
    private lateinit var tvRadiusLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        SettingsRepository.init(this)
        setTheme(SettingsRepository.theme.styleResId())
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        tvSizeEstimate = findViewById(R.id.tvSizeEstimate)
        tvBitrateLabel = findViewById(R.id.tvBitrateLabel)
        tvRadiusLabel = findViewById(R.id.tvRadiusLabel)

        setupResolution()
        setupFrameRate()
        setupBitrate()
        setupCodec()
        setupAspectRatio()
        setupSeekStep()
        setupMicSource()
        setupRecordingToggles()
        setupTheme()
        setupCornerRadius()
        setupBorder()
        updateSizeEstimate()

        findViewById<Button>(R.id.btnResetPipLayout).setOnClickListener {
            SettingsRepository.savePipRect(PIP_PRESETS[0])
            android.widget.Toast.makeText(this, "PIP layout reset to default", android.widget.Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.btnDoneSettings).setOnClickListener { finish() }
    }

    private fun setupResolution() {
        val group = findViewById<RadioGroup>(R.id.groupResolution)
        val map = mapOf(
            R.id.res480 to ResolutionOption.P480,
            R.id.res720 to ResolutionOption.P720,
            R.id.res1080 to ResolutionOption.P1080,
            R.id.res4k to ResolutionOption.UHD4K
        )
        map.entries.first { it.value == SettingsRepository.resolution }.let {
            findViewById<RadioButton>(it.key).isChecked = true
        }
        group.setOnCheckedChangeListener { _, checkedId ->
            map[checkedId]?.let { SettingsRepository.resolution = it }
            updateSizeEstimate()
        }
    }

    private fun setupFrameRate() {
        val group = findViewById<RadioGroup>(R.id.groupFps)
        val map = mapOf(R.id.fps15 to 15, R.id.fps24 to 24, R.id.fps30 to 30, R.id.fps60 to 60)
        map.entries.first { it.value == SettingsRepository.frameRate }.let {
            findViewById<RadioButton>(it.key).isChecked = true
        }
        group.setOnCheckedChangeListener { _, checkedId ->
            map[checkedId]?.let { SettingsRepository.frameRate = it }
        }
    }

    private fun setupBitrate() {
        val seekBar = findViewById<SeekBar>(R.id.seekBitrate)
        seekBar.progress = (SettingsRepository.bitrateMbps - 1).coerceIn(0, 29)
        updateBitrateLabel()
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                SettingsRepository.bitrateMbps = progress + 1
                updateBitrateLabel()
                updateSizeEstimate()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    }

    private fun updateBitrateLabel() {
        tvBitrateLabel.text = "Bitrate: ${SettingsRepository.bitrateMbps} Mbps"
    }

    private fun setupCodec() {
        val group = findViewById<RadioGroup>(R.id.groupCodec)
        val map = mapOf(R.id.codecH264 to CodecOption.H264, R.id.codecH265 to CodecOption.H265)
        map.entries.first { it.value == SettingsRepository.codec }.let {
            findViewById<RadioButton>(it.key).isChecked = true
        }
        group.setOnCheckedChangeListener { _, checkedId ->
            map[checkedId]?.let { SettingsRepository.codec = it }
        }
    }

    private fun setupAspectRatio() {
        val group = findViewById<RadioGroup>(R.id.groupAspect)
        val map = mapOf(
            R.id.aspect916 to AspectRatioOption.R9_16,
            R.id.aspect169 to AspectRatioOption.R16_9,
            R.id.aspect11 to AspectRatioOption.R1_1,
            R.id.aspect43 to AspectRatioOption.R4_3
        )
        map.entries.first { it.value == SettingsRepository.aspectRatio }.let {
            findViewById<RadioButton>(it.key).isChecked = true
        }
        group.setOnCheckedChangeListener { _, checkedId ->
            map[checkedId]?.let { SettingsRepository.aspectRatio = it }
        }
    }

    private fun setupSeekStep() {
        val spinner = findViewById<Spinner>(R.id.spinnerSeekStep)
        val options = SettingsRepository.SEEK_STEP_OPTIONS.toList()
        val labels = options.map { "$it seconds" }
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, labels).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        val currentIndex = options.indexOf(SettingsRepository.seekStepSeconds).coerceAtLeast(0)
        spinner.setSelection(currentIndex)
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                SettingsRepository.seekStepSeconds = options[position]
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }
    }

    /** Radio buttons are built at runtime since which inputs exist depends on what's physically connected right now. */
    private fun setupMicSource() {
        val container = findViewById<android.widget.LinearLayout>(R.id.llMicOptions)
        val available = AudioInputHelper.availableInputs(this)
        val group = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        val buttonsBySource = mutableMapOf<Int, MicSource>()

        available.forEachIndexed { index, source ->
            val rb = RadioButton(this).apply {
                id = android.view.View.generateViewId()
                text = source.label
                setTextColor(android.graphics.Color.WHITE)
                textSize = 14f
                buttonTintList = android.content.res.ColorStateList.valueOf(android.graphics.Color.parseColor(SettingsRepository.theme.accent))
            }
            buttonsBySource[rb.id] = source
            group.addView(rb)
            if (source == SettingsRepository.micSource) rb.isChecked = true
        }
        // If the previously chosen source is no longer plugged in, fall back visibly to Default.
        if (buttonsBySource.values.none { it == SettingsRepository.micSource }) {
            (group.getChildAt(0) as? RadioButton)?.isChecked = true
            SettingsRepository.micSource = MicSource.DEFAULT
        }

        group.setOnCheckedChangeListener { _, checkedId ->
            buttonsBySource[checkedId]?.let { SettingsRepository.micSource = it }
        }
        container.removeAllViews()
        container.addView(group)
    }

    private fun setupRecordingToggles() {
        findViewById<Switch>(R.id.switchDockCompact).apply {
            isChecked = SettingsRepository.controlDockCompact
            setOnCheckedChangeListener { _, isChecked -> SettingsRepository.controlDockCompact = isChecked }
        }
        findViewById<Switch>(R.id.switchAutoHide).apply {
            isChecked = SettingsRepository.autoHideControls
            setOnCheckedChangeListener { _, isChecked -> SettingsRepository.autoHideControls = isChecked }
        }
        findViewById<Switch>(R.id.switchRecordingBorder).apply {
            isChecked = SettingsRepository.recordingBorderEnabled
            setOnCheckedChangeListener { _, isChecked -> SettingsRepository.recordingBorderEnabled = isChecked }
        }
    }

    private fun setupTheme() {
        val group = findViewById<RadioGroup>(R.id.groupTheme)
        val map = mapOf(
            R.id.themeMidnight to AppTheme.MIDNIGHT,
            R.id.themeOcean to AppTheme.OCEAN,
            R.id.themeEmerald to AppTheme.EMERALD,
            R.id.themeSunset to AppTheme.SUNSET
        )
        map.entries.first { it.value == SettingsRepository.theme }.let {
            findViewById<RadioButton>(it.key).isChecked = true
        }
        group.setOnCheckedChangeListener { _, checkedId ->
            val newTheme = map[checkedId] ?: return@setOnCheckedChangeListener
            if (newTheme != SettingsRepository.theme) {
                SettingsRepository.theme = newTheme
                recreate() // re-apply the new theme's colors immediately
            }
        }
    }

    private fun setupCornerRadius() {
        val seekBar = findViewById<SeekBar>(R.id.seekCornerRadius)
        seekBar.progress = SettingsRepository.pipCornerRadiusDp
        updateRadiusLabel()
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                SettingsRepository.pipCornerRadiusDp = progress
                updateRadiusLabel()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    }

    private fun updateRadiusLabel() {
        tvRadiusLabel.text = "PIP corner roundness: ${SettingsRepository.pipCornerRadiusDp}dp"
    }

    private fun setupBorder() {
        val switchView = findViewById<Switch>(R.id.switchPipBorder)
        switchView.isChecked = SettingsRepository.pipBorderEnabled
        switchView.setOnCheckedChangeListener { _, isChecked ->
            SettingsRepository.pipBorderEnabled = isChecked
        }
    }

    private fun updateSizeEstimate() {
        val mbPerMin = SettingsRepository.estimatedMbPerMinute()
        tvSizeEstimate.text = String.format(
            Locale.US,
            "Estimated size: ~%.1f MB per minute of recording at %s / %d Mbps",
            mbPerMin, SettingsRepository.resolution.label, SettingsRepository.bitrateMbps
        )
    }
}
