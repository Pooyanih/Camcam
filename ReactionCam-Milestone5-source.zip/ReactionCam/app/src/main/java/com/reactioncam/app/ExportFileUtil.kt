package com.reactioncam.app

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File

object ExportFileUtil {

    /** A representative frame from the finished video, for the Recording Complete screen. */
    fun generateThumbnail(path: String): Bitmap? {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(path)
            retriever.getFrameAtTime(0)
        } catch (e: Exception) {
            null
        } finally {
            retriever.release()
        }
    }

    /** A content:// URI other apps (and our own Preview/Share) can open, even before the file is in MediaStore. */
    fun uriForTempFile(context: Context, file: File): Uri {
        return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    }

    /** Keeps a user-entered filename safe to use on disk / in MediaStore. */
    fun sanitizeFileName(name: String): String {
        val cleaned = name.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_")
        return cleaned.ifBlank { "Reaction_${System.currentTimeMillis()}" }
    }
}
