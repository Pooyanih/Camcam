package com.reactioncam.app.export

import android.graphics.SurfaceTexture
import android.view.Surface

/**
 * Wraps a GL external-OES texture + SurfaceTexture + Surface, for use as a
 * MediaCodec decoder's output surface. [awaitNewFrame] blocks the calling (rendering)
 * thread until the decoder has actually delivered a frame, which is what lets us
 * drive rendering in lockstep with decoding instead of racing it.
 */
class FrameTexture {
    val textureId: Int = createExternalOesTexture()
    val surfaceTexture: SurfaceTexture = SurfaceTexture(textureId)
    val surface: Surface = Surface(surfaceTexture)

    private val lock = Object()
    private var frameAvailable = false

    init {
        surfaceTexture.setOnFrameAvailableListener {
            synchronized(lock) {
                frameAvailable = true
                lock.notifyAll()
            }
        }
    }

    fun awaitNewFrame(timeoutMs: Long = 2000) {
        synchronized(lock) {
            val deadline = System.currentTimeMillis() + timeoutMs
            while (!frameAvailable) {
                val remaining = deadline - System.currentTimeMillis()
                if (remaining <= 0) throw RuntimeException("Timed out waiting for decoded frame")
                (lock as java.lang.Object).wait(remaining)
            }
            frameAvailable = false
        }
        surfaceTexture.updateTexImage()
    }

    fun getTransformMatrix(): FloatArray {
        val matrix = FloatArray(16)
        surfaceTexture.getTransformMatrix(matrix)
        return matrix
    }

    fun release() {
        surface.release()
        surfaceTexture.release()
    }
}
