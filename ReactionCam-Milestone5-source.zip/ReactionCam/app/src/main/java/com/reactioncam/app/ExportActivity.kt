package com.reactioncam.app

import android.app.AlertDialog
import android.graphics.Bitmap
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.reactioncam.app.export.PlaybackTimeline
import com.reactioncam.app.export.VideoCompositor
import com.reactioncam.app.settings.SettingsRepository
import com.reactioncam.app.settings.styleResId
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Runs [VideoCompositor] off the UI thread, shows a progress screen, then the
 * Recording Complete screen: a thumbnail, an editable filename, and Preview / Share /
 * Save to Gallery / Open in Gallery / Delete. Preview and Share work on the temp file
 * (via FileProvider) even before you tap Save, so you can check the result and back
 * out without ever touching the gallery.
 */
class ExportActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_CAMERA_TAKE_PATH = "extra_camera_take_path"
        const val EXTRA_SOURCE_VIDEO_URI = "extra_source_video_uri"
        const val EXTRA_PIP_RECT = "extra_pip_rect"
        const val EXTRA_TIMELINE = "extra_timeline"
        private const val TAG = "ExportActivity"
    }

    private var tempOutputFile: File? = null
    private var savedUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        SettingsRepository.init(this)
        setTheme(SettingsRepository.theme.styleResId())
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_export)

        val cameraTakePath = intent.getStringExtra(EXTRA_CAMERA_TAKE_PATH)
        @Suppress("DEPRECATION")
        val sourceUri = intent.getParcelableExtra<Uri>(EXTRA_SOURCE_VIDEO_URI)
        val pipRect = intent.getFloatArrayExtra(EXTRA_PIP_RECT)
        @Suppress("DEPRECATION")
        val timeline = intent.getSerializableExtra(EXTRA_TIMELINE) as? PlaybackTimeline

        if (cameraTakePath == null || sourceUri == null || pipRect == null || timeline == null) {
            Toast.makeText(this, "Something went wrong preparing your video.", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        startExport(File(cameraTakePath), sourceUri, pipRect, timeline)
    }

    private fun startExport(cameraTake: File, sourceUri: Uri, pipRect: FloatArray, timeline: PlaybackTimeline) {
        val outFile = File(cacheDir, "reaction_export_${System.currentTimeMillis()}.mp4")
        tempOutputFile = outFile

        Thread {
            try {
                val compositor = VideoCompositor(
                    context = applicationContext,
                    cameraTakeFile = cameraTake,
                    sourceVideoUri = sourceUri,
                    pipRectNormalized = pipRect,
                    timeline = timeline,
                    outputFile = outFile,
                    onProgress = { progress ->
                        runOnUiThread { updateProgress(progress) }
                    }
                )
                compositor.run()
                cameraTake.delete() // intermediate camera take is no longer needed either way

                // Decode the thumbnail frame here too — it's the same kind of work as
                // the compositor itself (opening/parsing the mp4), so it belongs off
                // the UI thread, not synchronously right as the screen appears.
                val thumbnail = ExportFileUtil.generateThumbnail(outFile.absolutePath)

                runOnUiThread { showRecordingComplete(outFile, thumbnail) }
            } catch (e: Exception) {
                Log.e(TAG, "Export failed", e)
                runOnUiThread { showError("Export failed: ${e.message}") }
            }
        }.start()
    }

    private fun updateProgress(progress: Float) {
        findViewById<TextView>(R.id.tvProgressPercent).text = "${(progress * 100).toInt()}%"
    }

    private fun showError(message: String) {
        findViewById<TextView>(R.id.tvStatus).text = message
        findViewById<android.widget.ProgressBar>(R.id.progressBar).visibility = android.view.View.GONE
    }

    private fun showRecordingComplete(outFile: File, thumbnail: Bitmap?) {
        findViewById<android.widget.ProgressBar>(R.id.progressBar).visibility = android.view.View.GONE
        findViewById<TextView>(R.id.tvStatus).visibility = android.view.View.GONE
        findViewById<TextView>(R.id.tvProgressPercent).visibility = android.view.View.GONE
        findViewById<android.widget.LinearLayout>(R.id.doneLayout).visibility = android.view.View.VISIBLE

        val ivThumbnail = findViewById<ImageView>(R.id.ivThumbnail)
        val etFileName = findViewById<EditText>(R.id.etFileName)
        val btnPreview = findViewById<Button>(R.id.btnPreview)
        val btnShare = findViewById<Button>(R.id.btnShare)
        val btnSave = findViewById<Button>(R.id.btnSave)
        val btnOpenGallery = findViewById<Button>(R.id.btnOpenGallery)
        val btnDelete = findViewById<Button>(R.id.btnDelete)
        val btnDone = findViewById<Button>(R.id.btnDone)

        if (thumbnail != null) ivThumbnail.setImageBitmap(thumbnail)

        val defaultName = "Reaction_${SimpleDateFormat("yyyy-MM-dd_HH-mm", Locale.US).format(Date())}"
        etFileName.setText(defaultName)

        fun currentShareableUri(): Uri = savedUri ?: ExportFileUtil.uriForTempFile(this, outFile)

        btnPreview.setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(currentShareableUri(), "video/mp4")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            })
        }

        btnShare.setOnClickListener {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = "video/mp4"
                putExtra(Intent.EXTRA_STREAM, currentShareableUri())
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }, "Share reaction video"))
        }

        btnSave.setOnClickListener {
            val name = ExportFileUtil.sanitizeFileName(etFileName.text.toString())
            btnSave.isEnabled = false
            btnSave.text = "Saving…"
            Thread {
                val result = MediaStoreUtil.saveVideoToGallery(applicationContext, outFile, "$name.mp4")
                runOnUiThread {
                    if (result != null) {
                        savedUri = result
                        outFile.delete()
                        tempOutputFile = null
                        btnSave.text = "✅ Saved"
                        btnOpenGallery.isEnabled = true
                        etFileName.isEnabled = false
                        Toast.makeText(this, "Saved to your gallery", Toast.LENGTH_SHORT).show()
                    } else {
                        btnSave.text = "💾 Save to Gallery"
                        btnSave.isEnabled = true
                        Toast.makeText(this, "Could not save the video to your gallery.", Toast.LENGTH_LONG).show()
                    }
                }
            }.start()
        }

        btnOpenGallery.setOnClickListener {
            val uri = savedUri ?: return@setOnClickListener
            startActivity(Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "video/mp4")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            })
        }

        btnDelete.setOnClickListener { confirmDelete() }
        btnDone.setOnClickListener { attemptGoHome() }
    }

    private fun confirmDelete() {
        AlertDialog.Builder(this)
            .setTitle("Delete this recording?")
            .setMessage("This can't be undone.")
            .setPositiveButton("Delete") { _, _ ->
                Thread {
                    tempOutputFile?.delete()
                    savedUri?.let { contentResolver.delete(it, null, null) }
                    runOnUiThread { goHome() }
                }.start()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun attemptGoHome() {
        if (savedUri == null && tempOutputFile != null) {
            AlertDialog.Builder(this)
                .setTitle("Video not saved")
                .setMessage("You haven't saved this recording to your gallery yet. Leave anyway and discard it?")
                .setPositiveButton("Discard") { _, _ ->
                    tempOutputFile?.delete()
                    goHome()
                }
                .setNegativeButton("Stay", null)
                .show()
        } else {
            goHome()
        }
    }

    private fun goHome() {
        startActivity(Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
        })
        finish()
    }
}
