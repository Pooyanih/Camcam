package com.reactioncam.app.export

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat

/**
 * Decodes a single video track, one frame at a time, directly onto a [FrameTexture]'s
 * Surface. Two of these run side by side in [VideoCompositor]: one for the camera
 * take (stepped one frame at a time, driving the whole export's pacing) and one for
 * the source video (advanced to whatever timestamp the pause log says it should be
 * at, or held still while "frozen").
 */
class VideoTrackDecoder(
    private val extractor: MediaExtractor,
    trackIndex: Int,
    outputSurface: android.view.Surface
) {
    val format: MediaFormat = extractor.getTrackFormat(trackIndex)
    private val codec: MediaCodec

    var outputEos = false
        private set
    var lastRenderedPtsUs = -1L
        private set
    private var inputEos = false

    init {
        extractor.selectTrack(trackIndex)
        val mime = format.getString(MediaFormat.KEY_MIME)!!
        codec = MediaCodec.createDecoderByType(mime)
        codec.configure(format, outputSurface, null, 0)
        codec.start()
    }

    /** Decodes and renders exactly one new output frame; returns its pts, or null at EOS. */
    fun decodeNextFrame(frameTexture: FrameTexture): Long? {
        if (outputEos) return null
        val info = MediaCodec.BufferInfo()
        while (true) {
            feedInputIfPossible()
            val outIdx = codec.dequeueOutputBuffer(info, 10_000)
            if (outIdx >= 0) {
                val render = info.size > 0
                codec.releaseOutputBuffer(outIdx, render)
                if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                    outputEos = true
                }
                if (render) {
                    frameTexture.awaitNewFrame()
                    lastRenderedPtsUs = info.presentationTimeUs
                    return lastRenderedPtsUs
                }
                if (outputEos) return null
            }
            // INFO_TRY_AGAIN_LATER / INFO_OUTPUT_FORMAT_CHANGED: just loop.
        }
    }

    /** Decodes forward until a rendered frame's pts >= [targetPtsUs], or EOS. */
    fun advanceTo(targetPtsUs: Long, frameTexture: FrameTexture) {
        if (outputEos) return
        while (lastRenderedPtsUs < targetPtsUs && !outputEos) {
            decodeNextFrame(frameTexture)
        }
    }

    private fun feedInputIfPossible() {
        if (inputEos) return
        val inIdx = codec.dequeueInputBuffer(0)
        if (inIdx < 0) return
        val buffer = codec.getInputBuffer(inIdx) ?: return
        val sampleSize = extractor.readSampleData(buffer, 0)
        if (sampleSize < 0) {
            codec.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
            inputEos = true
        } else {
            val pts = extractor.sampleTime
            codec.queueInputBuffer(inIdx, 0, sampleSize, pts, 0)
            extractor.advance()
        }
    }

    fun release() {
        codec.stop()
        codec.release()
    }
}
