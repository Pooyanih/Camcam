package com.reactioncam.app

import android.content.Context
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.GradientDrawable
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import androidx.media3.ui.PlayerView
import com.reactioncam.app.settings.PipRect
import com.reactioncam.app.settings.SettingsRepository
import kotlin.math.max

/**
 * A movable, resizable box that hosts the source-video PlayerView on top of the
 * fullscreen camera preview. Drag anywhere on the box to move it; drag the bottom-right
 * handle to resize it; double-tap to cycle through quick preset layouts. Corner
 * roundness and an optional border follow [SettingsRepository]'s Look & Layout
 * settings, and are re-applied here for the live preview AND baked into the
 * exported video via the matching rounded-rect shader in GlUtil.kt, so what you see
 * while recording matches the finished file.
 */
class PipOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    val playerView: PlayerView

    private val handleSizePx = (20 * resources.displayMetrics.density).toInt()
    private val handle = View(context).apply {
        setBackgroundColor(Color.parseColor("#CCFFFFFF"))
    }

    private val minSizePx = (80 * resources.displayMetrics.density).toInt()
    private var cornerRadiusFraction = 0f
    private var borderDrawable: GradientDrawable? = null

    private var mode = Mode.NONE
    private var lastRawX = 0f
    private var lastRawY = 0f
    private var startWidth = 0
    private var startHeight = 0
    private var presetIndex = 0

    private enum class Mode { NONE, DRAG, RESIZE }

    private val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDoubleTap(e: MotionEvent): Boolean {
            cyclePreset()
            return true
        }
    })

    init {
        // Inflated from XML (rather than `PlayerView(context)`) so it renders with a
        // TextureView instead of a SurfaceView — see pip_player_view.xml for why.
        playerView = android.view.LayoutInflater.from(context)
            .inflate(com.reactioncam.app.R.layout.pip_player_view, this, false) as PlayerView
        addView(playerView, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        addView(handle, LayoutParams(handleSizePx, handleSizePx, android.view.Gravity.BOTTOM or android.view.Gravity.END))
        isClickable = true

        clipToOutline = true
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                val radiusPx = cornerRadiusFraction * minOf(view.width, view.height)
                outline.setRoundRect(0, 0, view.width, view.height, radiusPx)
            }
        }
        applyAppearanceFromSettings()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        invalidateOutline()
        updateBorderRadiusForCurrentSize()
    }

    /** Re-reads corner radius / border from settings; call after they might have changed. */
    fun applyAppearanceFromSettings() {
        // Interpreted as a fraction of the box's shorter side (0..40 setting -> 0..50%),
        // not a literal dp value, so "roundness" looks the same on screen and in the
        // exported video even though the two are rendered at completely different
        // pixel resolutions (see the matching fraction-based radius in VideoCompositor).
        cornerRadiusFraction = (SettingsRepository.pipCornerRadiusDp / 80f).coerceIn(0f, 0.5f)
        invalidateOutline()
        rebuildBorderDrawable()
    }

    /**
     * Creates (or clears) the border drawable. Only called when the border setting,
     * theme, or roundness actually changes — NOT on every resize frame, since
     * allocating a new GradientDrawable per pixel of a drag gesture is exactly the
     * kind of GC churn that shows up as visible stutter while resizing mid-recording.
     */
    private fun rebuildBorderDrawable() {
        if (SettingsRepository.pipBorderEnabled) {
            val radiusPx = cornerRadiusFraction * minOf(width, height).coerceAtLeast(1)
            val drawable = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = radiusPx
                setStroke((3 * resources.displayMetrics.density).toInt(), Color.parseColor(SettingsRepository.theme.accent))
                setColor(Color.TRANSPARENT)
            }
            borderDrawable = drawable
            foreground = drawable
        } else {
            borderDrawable = null
            foreground = null
        }
    }

    /** Cheap in-place update (no allocation) so live-resizing the box stays smooth. */
    private fun updateBorderRadiusForCurrentSize() {
        if (width <= 0 || height <= 0) return
        borderDrawable?.cornerRadius = cornerRadiusFraction * minOf(width, height)
    }

    private fun cyclePreset() {
        val parentView = parent as? ViewGroup ?: return
        presetIndex = (presetIndex + 1) % com.reactioncam.app.settings.PIP_PRESETS.size
        applyRect(com.reactioncam.app.settings.PIP_PRESETS[presetIndex], parentView.width, parentView.height)
    }

    /** Positions/sizes this box from a normalized (fraction-based) rect, e.g. a preset or the remembered layout. */
    fun applyRect(rect: PipRect, containerWidth: Int, containerHeight: Int) {
        if (containerWidth <= 0 || containerHeight <= 0) return
        val lp = layoutParams
        lp.width = (rect.wFrac * containerWidth).toInt().coerceAtLeast(minSizePx)
        lp.height = (rect.hFrac * containerHeight).toInt().coerceAtLeast(minSizePx)
        layoutParams = lp
        x = (rect.xFrac * containerWidth).coerceIn(0f, (containerWidth - lp.width).toFloat().coerceAtLeast(0f))
        y = (rect.yFrac * containerHeight).coerceIn(0f, (containerHeight - lp.height).toFloat().coerceAtLeast(0f))
        invalidateOutline()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        gestureDetector.onTouchEvent(event)
        val parentView = parent as? ViewGroup ?: return super.onTouchEvent(event)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastRawX = event.rawX
                lastRawY = event.rawY
                startWidth = width
                startHeight = height
                val local = floatArrayOf(event.x, event.y)
                mode = if (local[0] >= width - handleSizePx * 1.5f && local[1] >= height - handleSizePx * 1.5f) {
                    Mode.RESIZE
                } else {
                    Mode.DRAG
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - lastRawX
                val dy = event.rawY - lastRawY
                when (mode) {
                    Mode.DRAG -> {
                        val newX = (x + dx).coerceIn(0f, (parentView.width - width).toFloat())
                        val newY = (y + dy).coerceIn(0f, (parentView.height - height).toFloat())
                        x = newX
                        y = newY
                    }
                    Mode.RESIZE -> {
                        val newWidth = max(minSizePx, (startWidth + dx).toInt())
                            .coerceAtMost(parentView.width - x.toInt())
                        val newHeight = max(minSizePx, (startHeight + dy).toInt())
                            .coerceAtMost(parentView.height - y.toInt())
                        val lp = layoutParams
                        lp.width = newWidth
                        lp.height = newHeight
                        layoutParams = lp
                        invalidateOutline()
                    }
                    Mode.NONE -> {}
                }
                lastRawX = event.rawX
                lastRawY = event.rawY
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                mode = Mode.NONE
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    /**
     * Rect of this box relative to [container]'s coordinate space, as fractions (0..1).
     * Used by the exporter to place the PiP overlay at the same relative position/size
     * in the final rendered video, regardless of the recording screen's pixel dimensions.
     */
    fun normalizedRect(container: View): FloatArray {
        val cw = container.width.toFloat().coerceAtLeast(1f)
        val ch = container.height.toFloat().coerceAtLeast(1f)
        return floatArrayOf(x / cw, y / ch, width / cw, height / ch)
    }

    fun normalizedRectAsPipRect(container: View): PipRect {
        val a = normalizedRect(container)
        return PipRect(a[0], a[1], a[2], a[3])
    }
}
