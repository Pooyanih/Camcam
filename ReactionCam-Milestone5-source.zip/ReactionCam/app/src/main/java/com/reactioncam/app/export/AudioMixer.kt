package com.reactioncam.app.export

import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Decodes the mic audio (from the camera take) and the source video's own audio,
 * mixes them together with the source ducked slightly behind the mic, and re-encodes
 * the result as a single AAC track — all in one offline pass, independent of the
 * video render loop. This is what actually fixes "no audio at all": the previous
 * version tried to remux the mic track directly but never selected it on its
 * extractor, so nothing was ever read. Mixing properly also lets the source video's
 * own sound come through (frozen/relocated in sync with pauses and seeks, via the
 * same [PlaybackTimeline] the video uses), instead of it staying muted.
 */
object AudioMixer {

    private data class PcmAudio(val samples: ShortArray, val sampleRate: Int, val channelCount: Int)

    /** Returns the final audio MediaFormat plus every encoded AAC access unit, or null if there's no audio at all. */
    fun mixAndEncode(
        context: Context,
        cameraTakeFile: File,
        sourceVideoUri: Uri,
        timeline: PlaybackTimeline,
        totalDurationMs: Long,
        sourceVolume: Float = 0.5f
    ): Pair<MediaFormat, List<Pair<ByteArray, MediaCodec.BufferInfo>>>? {

        val micPcm = decodeTrackAudio(cameraTakeFile.absolutePath, null, context)
        val sourcePcm = decodeTrackAudio(null, sourceVideoUri, context)

        if (micPcm == null && sourcePcm == null) return null

        val targetRate = micPcm?.sampleRate ?: sourcePcm!!.sampleRate
        val targetChannels = micPcm?.channelCount ?: sourcePcm!!.channelCount

        val micAdjusted = micPcm?.let { resample(it, targetRate, targetChannels) } ?: ShortArray(0)
        val sourceAdjusted = sourcePcm?.let { resample(it, targetRate, targetChannels) }

        val mixed = mix(micAdjusted, sourceAdjusted, targetRate, targetChannels, totalDurationMs, timeline, sourceVolume)
        return encodeToAac(mixed, targetRate, targetChannels)
    }

    private fun decodeTrackAudio(path: String?, uri: Uri?, context: Context): PcmAudio? {
        val extractor = MediaExtractor()
        try {
            if (path != null) {
                extractor.setDataSource(path)
            } else {
                context.contentResolver.openFileDescriptor(uri!!, "r")?.use { pfd ->
                    extractor.setDataSource(pfd.fileDescriptor)
                } ?: return null
            }
            var trackIndex = -1
            for (i in 0 until extractor.trackCount) {
                val mime = extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) {
                    trackIndex = i
                    break
                }
            }
            if (trackIndex < 0) return null

            extractor.selectTrack(trackIndex)
            val format = extractor.getTrackFormat(trackIndex)
            val mime = format.getString(MediaFormat.KEY_MIME)!!
            val sampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            val channelCount = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)

            val codec = MediaCodec.createDecoderByType(mime)
            codec.configure(format, null, null, 0)
            codec.start()

            val output = ByteArrayOutputStream()
            var inputEos = false
            val info = MediaCodec.BufferInfo()

            while (true) {
                if (!inputEos) {
                    val inIdx = codec.dequeueInputBuffer(10_000)
                    if (inIdx >= 0) {
                        val buf = codec.getInputBuffer(inIdx)!!
                        val size = extractor.readSampleData(buf, 0)
                        if (size < 0) {
                            codec.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputEos = true
                        } else {
                            codec.queueInputBuffer(inIdx, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val outIdx = codec.dequeueOutputBuffer(info, 10_000)
                if (outIdx >= 0) {
                    if (info.size > 0) {
                        val outBuf = codec.getOutputBuffer(outIdx)!!
                        outBuf.position(info.offset)
                        outBuf.limit(info.offset + info.size)
                        val bytes = ByteArray(info.size)
                        outBuf.get(bytes)
                        output.write(bytes)
                    }
                    val eos = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                    codec.releaseOutputBuffer(outIdx, false)
                    if (eos) break
                }
            }
            codec.stop()
            codec.release()

            val bytes = output.toByteArray()
            val shorts = ShortArray(bytes.size / 2)
            ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(shorts)
            return PcmAudio(shorts, sampleRate, channelCount)
        } catch (e: Exception) {
            return null
        } finally {
            extractor.release()
        }
    }

    private fun adjustChannels(samples: ShortArray, from: Int, to: Int): ShortArray {
        if (from == to || from == 0) return samples
        val frames = samples.size / from
        val out = ShortArray(frames * to)
        for (f in 0 until frames) {
            when {
                from == 1 && to == 2 -> {
                    val v = samples[f]
                    out[f * 2] = v; out[f * 2 + 1] = v
                }
                from == 2 && to == 1 -> {
                    val l = samples[f * 2]; val r = samples[f * 2 + 1]
                    out[f] = ((l + r) / 2).toShort()
                }
                else -> {
                    var sum = 0
                    for (c in 0 until from) sum += samples[f * from + c]
                    val avg = (sum / from).toShort()
                    for (c in 0 until to) out[f * to + c] = avg
                }
            }
        }
        return out
    }

    private fun resample(input: PcmAudio, targetRate: Int, targetChannels: Int): ShortArray {
        val channelAdjusted = adjustChannels(input.samples, input.channelCount, targetChannels)
        if (input.sampleRate == targetRate || targetChannels == 0) return channelAdjusted

        val ratio = targetRate.toDouble() / input.sampleRate.toDouble()
        val inFrames = channelAdjusted.size / targetChannels
        val outFrames = (inFrames * ratio).toInt().coerceAtLeast(0)
        val out = ShortArray(outFrames * targetChannels)
        for (i in 0 until outFrames) {
            val srcPosF = i / ratio
            val srcIdx = srcPosF.toInt().coerceIn(0, (inFrames - 1).coerceAtLeast(0))
            val nextIdx = (srcIdx + 1).coerceAtMost((inFrames - 1).coerceAtLeast(0))
            val frac = (srcPosF - srcIdx).toFloat()
            for (c in 0 until targetChannels) {
                val a = channelAdjusted[srcIdx * targetChannels + c]
                val b = channelAdjusted[nextIdx * targetChannels + c]
                out[i * targetChannels + c] = (a + (b - a) * frac).toInt().toShort()
            }
        }
        return out
    }

    private fun mix(
        micPcm: ShortArray,
        sourcePcm: ShortArray?,
        rate: Int,
        channels: Int,
        totalDurationMs: Long,
        timeline: PlaybackTimeline,
        sourceVolume: Float
    ): ShortArray {
        val totalFrames = (totalDurationMs * rate / 1000).toInt().coerceAtLeast(0)
        val out = ShortArray(totalFrames * channels)
        val micFrames = micPcm.size / channels.coerceAtLeast(1)
        val srcFrames = (sourcePcm?.size ?: 0) / channels.coerceAtLeast(1)
        val cursor = timeline.createCursor()

        for (i in 0 until totalFrames) {
            val cameraMs = i.toLong() * 1000 / rate
            val micIdx = if (micFrames > 0) i.coerceAtMost(micFrames - 1) else -1
            val sourceMs = if (srcFrames > 0) cursor.sourceMsAt(cameraMs) else 0L
            val srcIdx = if (srcFrames > 0) {
                (sourceMs * rate / 1000).toInt().coerceIn(0, srcFrames - 1)
            } else -1

            for (c in 0 until channels) {
                var sample = if (micIdx >= 0) micPcm[micIdx * channels + c].toInt() else 0
                if (srcIdx >= 0) {
                    sample += (sourcePcm!![srcIdx * channels + c] * sourceVolume).toInt()
                }
                out[i * channels + c] = sample.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
            }
        }
        return out
    }

    private fun encodeToAac(
        pcm: ShortArray,
        sampleRate: Int,
        channelCount: Int
    ): Pair<MediaFormat, List<Pair<ByteArray, MediaCodec.BufferInfo>>> {
        val format = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sampleRate, channelCount).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, 128_000)
        }
        val encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        encoder.start()

        val results = mutableListOf<Pair<ByteArray, MediaCodec.BufferInfo>>()
        var outputFormat: MediaFormat = format

        val totalBytes = pcm.size * 2
        val sourceBuffer = ByteBuffer.allocate(totalBytes).order(ByteOrder.LITTLE_ENDIAN)
        sourceBuffer.asShortBuffer().put(pcm)

        val bytesPerFrame = 2 * channelCount
        var bytesFed = 0
        var presentationTimeUs = 0L
        var inputDone = false
        val info = MediaCodec.BufferInfo()

        while (true) {
            if (!inputDone) {
                val inIdx = encoder.dequeueInputBuffer(10_000)
                if (inIdx >= 0) {
                    val inBuf = encoder.getInputBuffer(inIdx)!!
                    inBuf.clear()
                    val remaining = totalBytes - bytesFed
                    if (remaining <= 0) {
                        encoder.queueInputBuffer(inIdx, 0, 0, presentationTimeUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        inputDone = true
                    } else {
                        val toWrite = minOf(remaining, inBuf.capacity())
                        val slice = ByteArray(toWrite)
                        sourceBuffer.position(bytesFed)
                        sourceBuffer.get(slice)
                        inBuf.put(slice)
                        encoder.queueInputBuffer(inIdx, 0, toWrite, presentationTimeUs, 0)
                        bytesFed += toWrite
                        val framesWritten = toWrite / bytesPerFrame
                        presentationTimeUs += framesWritten.toLong() * 1_000_000 / sampleRate
                    }
                }
            }

            val outIdx = encoder.dequeueOutputBuffer(info, 10_000)
            when {
                outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> outputFormat = encoder.outputFormat
                outIdx >= 0 -> {
                    if (info.size > 0 && info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG == 0) {
                        val outBuf = encoder.getOutputBuffer(outIdx)!!
                        outBuf.position(info.offset)
                        outBuf.limit(info.offset + info.size)
                        val data = ByteArray(info.size)
                        outBuf.get(data)
                        val infoCopy = MediaCodec.BufferInfo().apply {
                            set(0, data.size, info.presentationTimeUs, info.flags)
                        }
                        results.add(data to infoCopy)
                    }
                    val eos = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                    encoder.releaseOutputBuffer(outIdx, false)
                    if (eos) break
                }
            }
        }
        encoder.stop()
        encoder.release()
        return outputFormat to results
    }
}
