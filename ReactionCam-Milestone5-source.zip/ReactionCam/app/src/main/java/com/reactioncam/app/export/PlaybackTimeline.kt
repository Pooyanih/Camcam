package com.reactioncam.app.export

import java.io.Serializable

/**
 * One breakpoint in the source video's playback history: at [cameraElapsedMs] (time
 * since the camera recording started), the source video's own position became
 * [sourceMsAtEvent], and from then on it was either advancing normally ([playing] =
 * true) or frozen ([playing] = false). Covers pause, resume, rewind and fast-forward
 * with the same event shape — a seek is just a breakpoint that relocates
 * [sourceMsAtEvent] while keeping whatever play state was already active.
 */
data class TimelineEvent(
    val cameraElapsedMs: Long,
    val sourceMsAtEvent: Long,
    val playing: Boolean
) : Serializable

/**
 * Full playback history for one take. The exporter uses this to answer, for any point
 * in the camera recording's timeline, "what should the source video's position be
 * right now" — accounting for every pause, resume, rewind and fast-forward the user
 * made while recording.
 */
class PlaybackTimeline : Serializable {
    private val events = mutableListOf(TimelineEvent(0L, 0L, true))

    fun onPause(cameraElapsedMs: Long, sourceMsAtEvent: Long) {
        events.add(TimelineEvent(cameraElapsedMs, sourceMsAtEvent, false))
    }

    fun onResume(cameraElapsedMs: Long, sourceMsAtEvent: Long) {
        events.add(TimelineEvent(cameraElapsedMs, sourceMsAtEvent, true))
    }

    /** Rewind or fast-forward: relocates source time, keeps the current play/pause state. */
    fun onSeek(cameraElapsedMs: Long, newSourceMs: Long, wasPlaying: Boolean) {
        events.add(TimelineEvent(cameraElapsedMs, newSourceMs, wasPlaying))
    }

    /** One-off lookup (fine for the video loop: at most one call per output frame). */
    fun mapToSourceTimeMs(cameraElapsedMs: Long): Long {
        var applicable = events[0]
        for (e in events) {
            if (e.cameraElapsedMs > cameraElapsedMs) break
            applicable = e
        }
        return if (applicable.playing) {
            applicable.sourceMsAtEvent + (cameraElapsedMs - applicable.cameraElapsedMs)
        } else {
            applicable.sourceMsAtEvent
        }
    }

    /**
     * A forward-only cursor for the audio mixer, which queries millions of
     * monotonically increasing timestamps and can't afford an O(events) scan each time.
     */
    fun createCursor(): Cursor = Cursor(events)

    class Cursor(private val events: List<TimelineEvent>) {
        private var idx = 0
        fun sourceMsAt(cameraElapsedMs: Long): Long {
            while (idx + 1 < events.size && events[idx + 1].cameraElapsedMs <= cameraElapsedMs) idx++
            val e = events[idx]
            return if (e.playing) e.sourceMsAtEvent + (cameraElapsedMs - e.cameraElapsedMs) else e.sourceMsAtEvent
        }
    }
}
