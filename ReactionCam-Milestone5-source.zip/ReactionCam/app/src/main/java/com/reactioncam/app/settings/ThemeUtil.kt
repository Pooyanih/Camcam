package com.reactioncam.app.settings

import com.reactioncam.app.R

fun AppTheme.styleResId(): Int = when (this) {
    AppTheme.MIDNIGHT -> R.style.Theme_ReactionCam_Midnight
    AppTheme.OCEAN -> R.style.Theme_ReactionCam_Ocean
    AppTheme.EMERALD -> R.style.Theme_ReactionCam_Emerald
    AppTheme.SUNSET -> R.style.Theme_ReactionCam_Sunset
}
