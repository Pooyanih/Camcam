package com.reactioncam.app

import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.Gravity
import android.widget.Button
import android.widget.FrameLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import com.reactioncam.app.export.PlaybackTimeline
import com.reactioncam.app.settings.AudioInputHelper
import com.reactioncam.app.settings.PIP_PRESETS
import com.reactioncam.app.settings.ResolutionOption
import com.reactioncam.app.settings.SettingsRepository
import java.io.File
import java.util.Locale

/**
 * Fullscreen recording screen. Front camera fills the background (CameraX), the
 * source video autoplays muted in a movable/resizable PipOverlayView, and every
 * pause/resume/rewind/fast-forward/scrub is timestamped into a PlaybackTimeline. The
 * camera take (with mic audio) is recorded to a temp file; the actual PiP compositing,
 * audio mixing, and Quality & Format settings are all applied afterwards in
 * ExportActivity, which reads them straight from SettingsRepository.
 *
 * Two distinct kinds of "pause" live here:
 *  - Pause the SOURCE VIDEO only (existing): camera keeps recording, tracked via
 *    [timeline] exactly as before.
 *  - Pause the ACTUAL RECORDING (new): calls CameraX's own Recording.pause()/resume(),
 *    which produces a continuous output file with the paused wall-clock time simply
 *    excluded — no gap, no frozen frame. Because of that, [cameraElapsedMs] (used for
 *    every timeline event this screen logs) has to exclude actual-recording-paused
 *    time too, or events logged after a recording pause would be timestamped against
 *    the wrong point in the compressed output file. See [accumulatedRecordingPauseMs].
 */
class RecordActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_SOURCE_VIDEO_URI = "extra_source_video_uri"
        private const val TAG = "RecordActivity"
        private const val RESUME_COUNTDOWN_SECONDS = 3
    }

    private lateinit var recordingCanvas: FrameLayout
    private lateinit var cameraPreview: PreviewView
    private lateinit var pipOverlay: PipOverlayView
    private lateinit var seekSourceVideo: SeekBar
    private lateinit var btnRewind: Button
    private lateinit var btnPauseResume: Button
    private lateinit var btnForward: Button
    private lateinit var btnPauseRecording: Button
    private lateinit var btnStop: Button
    private lateinit var tvTimer: TextView
    private lateinit var tvSourcePosition: TextView
    private lateinit var tvRecordingPaused: TextView
    private lateinit var tvCountdown: TextView
    private lateinit var topIndicatorRow: android.view.View
    private lateinit var bottomControlsContainer: android.view.View
    private lateinit var recordingBorderOverlay: android.view.View

    private lateinit var sourceVideoUri: Uri
    private var exoPlayer: ExoPlayer? = null

    private var videoCapture: VideoCapture<Recorder>? = null
    private var activeRecording: Recording? = null
    private var cameraTakeFile: File? = null

    private var recordingStartElapsedRealtime = 0L
    private val timeline = PlaybackTimeline()
    private var isSourcePaused = false
    private var isRecordingActive = false
    private var canvasWidthPx = 0
    private var canvasHeightPx = 0
    private var isUserScrubbing = false
    private var controlsHidden = false
    private val autoHideRunnable = Runnable { hideControls() }
    private var countdownRunnable: Runnable? = null

    // --- Actual-recording pause bookkeeping (see class doc) ---
    private var isRecordingPaused = false
    private var recordingPauseStartRealtime: Long? = null
    private var accumulatedRecordingPauseMs = 0L
    private var wasSourcePlayingBeforeRecordingPause = false

    private val uiHandler = Handler(Looper.getMainLooper())
    private val timerTick = object : Runnable {
        override fun run() {
            tvTimer.text = formatMs(cameraElapsedMs())

            exoPlayer?.let { player ->
                if (!isUserScrubbing) {
                    val duration = player.duration.coerceAtLeast(0)
                    seekSourceVideo.max = (duration / 1000).toInt().coerceAtLeast(1)
                    seekSourceVideo.progress = (player.currentPosition / 1000).toInt()
                    tvSourcePosition.text = String.format(
                        Locale.US, "%s / %s",
                        formatMs(player.currentPosition),
                        formatMs(duration)
                    )
                }
            }
            uiHandler.postDelayed(this, 250)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        SettingsRepository.init(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_record)

        @Suppress("DEPRECATION")
        val uri = intent.getParcelableExtra<Uri>(EXTRA_SOURCE_VIDEO_URI)
        if (uri == null) {
            Toast.makeText(this, "No source video provided", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        sourceVideoUri = uri

        recordingCanvas = findViewById(R.id.recordingCanvas)
        cameraPreview = findViewById(R.id.cameraPreview)
        pipOverlay = findViewById(R.id.pipOverlay)
        seekSourceVideo = findViewById(R.id.seekSourceVideo)
        btnRewind = findViewById(R.id.btnRewind)
        btnPauseResume = findViewById(R.id.btnPauseResume)
        btnForward = findViewById(R.id.btnForward)
        btnPauseRecording = findViewById(R.id.btnPauseRecording)
        btnStop = findViewById(R.id.btnStop)
        tvTimer = findViewById(R.id.tvTimer)
        tvSourcePosition = findViewById(R.id.tvSourcePosition)
        tvRecordingPaused = findViewById(R.id.tvRecordingPaused)
        tvCountdown = findViewById(R.id.tvCountdown)
        topIndicatorRow = findViewById(R.id.topIndicatorRow)
        bottomControlsContainer = findViewById(R.id.bottomControlsContainer)
        recordingBorderOverlay = findViewById(R.id.recordingBorderOverlay)

        val stepSeconds = SettingsRepository.seekStepSeconds
        btnRewind.text = "⏪ ${stepSeconds}s"
        btnForward.text = "${stepSeconds}s ⏩"

        applyThemeTint()
        applyControlDockStyle()
        setupAutoHide()
        setupRecordingCanvasAspect()
        setupSourcePlayer()
        setupScrubBar()
        startCamera()

        btnRewind.setOnClickListener { seekBy(-stepSeconds * 1000L) }
        btnForward.setOnClickListener { seekBy(stepSeconds * 1000L) }
        btnPauseResume.setOnClickListener { togglePause() }
        btnPauseRecording.setOnClickListener { toggleRecordingPause() }
        btnStop.setOnClickListener { stopEverything() }
    }

    /** Tints the transport buttons with the current theme's surface/accent so Look & Layout choices show up here too. */
    private fun applyThemeTint() {
        val theme = SettingsRepository.theme
        val surfaceTint = ColorStateList.valueOf(Color.parseColor(theme.surface))
        btnRewind.backgroundTintList = surfaceTint
        btnPauseResume.backgroundTintList = surfaceTint
        btnForward.backgroundTintList = surfaceTint
        btnPauseRecording.backgroundTintList = surfaceTint
    }

    /** "Compact / transparent control dock" setting: smaller buttons, more see-through, less in the way of framing. */
    private fun applyControlDockStyle() {
        if (!SettingsRepository.controlDockCompact) return
        bottomControlsContainer.alpha = 0.6f
        val compactHeightPx = (44 * resources.displayMetrics.density).toInt()
        for (button in listOf(btnRewind, btnPauseResume, btnForward, btnPauseRecording, btnStop)) {
            val lp = button.layoutParams
            lp.height = compactHeightPx
            button.layoutParams = lp
        }
        (bottomControlsContainer as? android.view.ViewGroup)?.setPadding(12, 8, 12, 8)
    }

    /** Fades the top/bottom chrome out after 3.5s of inactivity; any tap on the canvas brings it back. */
    private fun setupAutoHide() {
        if (!SettingsRepository.autoHideControls) return
        recordingCanvas.setOnClickListener { showControlsAndResetTimer() }
        showControlsAndResetTimer()
    }

    private fun showControlsAndResetTimer() {
        uiHandler.removeCallbacks(autoHideRunnable)
        if (controlsHidden) {
            bottomControlsContainer.animate().alpha(1f).setDuration(200).start()
            topIndicatorRow.animate().alpha(1f).setDuration(200).start()
            tvSourcePosition.animate().alpha(1f).setDuration(200).start()
            controlsHidden = false
        }
        if (SettingsRepository.autoHideControls) {
            uiHandler.postDelayed(autoHideRunnable, 3500)
        }
    }

    private fun hideControls() {
        bottomControlsContainer.animate().alpha(0f).setDuration(300).start()
        topIndicatorRow.animate().alpha(0f).setDuration(300).start()
        tvSourcePosition.animate().alpha(0f).setDuration(300).start()
        controlsHidden = true
    }

    /** Purely a screen indicator (never part of the exported video) — on for the duration of the take. */
    private fun updateRecordingBorder(visible: Boolean) {
        if (!SettingsRepository.recordingBorderEnabled) {
            recordingBorderOverlay.visibility = android.view.View.GONE
            return
        }
        if (visible && recordingBorderOverlay.background == null) {
            recordingBorderOverlay.background = android.graphics.drawable.GradientDrawable().apply {
                setStroke((4 * resources.displayMetrics.density).toInt(), Color.parseColor(SettingsRepository.theme.accent))
                setColor(Color.TRANSPARENT)
            }
        }
        recordingBorderOverlay.visibility = if (visible) android.view.View.VISIBLE else android.view.View.GONE
    }

    /**
     * Sizes [recordingCanvas] to the chosen export aspect ratio, letterboxed within
     * the screen, so what you frame while recording matches the final video's crop —
     * the exporter applies the exact same aspect ratio to the camera layer.
     */
    private fun setupRecordingCanvasAspect() {
        val root = recordingCanvas.parent as android.view.View
        root.viewTreeObserver.addOnGlobalLayoutListener(object : android.view.ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                root.viewTreeObserver.removeOnGlobalLayoutListener(this)
                val screenW = root.width
                val screenH = root.height
                if (screenW <= 0 || screenH <= 0) return

                val aspect = SettingsRepository.aspectRatio
                val targetRatio = aspect.wRatio.toFloat() / aspect.hRatio.toFloat()
                var boxW = screenW
                var boxH = (screenW / targetRatio).toInt()
                if (boxH > screenH) {
                    boxH = screenH
                    boxW = (screenH * targetRatio).toInt()
                }
                canvasWidthPx = boxW
                canvasHeightPx = boxH

                recordingCanvas.layoutParams = FrameLayout.LayoutParams(boxW, boxH, Gravity.CENTER)

                // Apply the remembered PIP layout (or the first preset) now that we know the canvas size.
                val remembered = SettingsRepository.loadPipRect() ?: PIP_PRESETS[0]
                pipOverlay.applyRect(remembered, boxW, boxH)
            }
        })
    }

    private fun formatMs(ms: Long): String {
        val totalSeconds = ms / 1000
        return String.format(Locale.US, "%02d:%02d", totalSeconds / 60, totalSeconds % 60)
    }

    private fun setupSourcePlayer() {
        val player = ExoPlayer.Builder(this).build().apply {
            setMediaItem(MediaItem.fromUri(sourceVideoUri))
            volume = 0f // The mic + source audio are mixed together in the export step instead.
            repeatMode = ExoPlayer.REPEAT_MODE_OFF
            playWhenReady = false
            prepare()
        }
        exoPlayer = player
        pipOverlay.playerView.player = player
    }

    /** Lets you drag the scrub bar to seek the source video, same bookkeeping as Rewind/Forward. */
    private fun setupScrubBar() {
        seekSourceVideo.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(sb: SeekBar?) {
                isUserScrubbing = true
            }
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    tvSourcePosition.text = String.format(
                        Locale.US, "%s / %s",
                        formatMs(progress * 1000L),
                        formatMs(exoPlayer?.duration?.coerceAtLeast(0) ?: 0L)
                    )
                }
            }
            override fun onStopTrackingTouch(sb: SeekBar?) {
                val player = exoPlayer
                isUserScrubbing = false
                if (player != null) {
                    val targetMs = (sb?.progress ?: 0) * 1000L
                    player.seekTo(targetMs)
                    timeline.onSeek(cameraElapsedMs(), targetMs, wasPlaying = !isSourcePaused)
                }
            }
        })
    }

    /**
     * Maps the Quality & Format resolution setting to the closest CameraX capture
     * preset. Note: this controls the *intermediate* camera take only. CameraX's
     * stable Recorder API doesn't expose arbitrary resolutions, exact frame rates, or
     * codec choice (H.264 vs H.265) for live capture — those need a raw Camera2 +
     * MediaCodec capture pipeline, which is a bigger architectural change than this
     * milestone. What actually matters — the resolution, frame rate, bitrate, codec,
     * and aspect ratio of the FINAL saved video — are all genuinely and exactly
     * applied in VideoCompositor, since that pipeline is raw MediaCodec I control
     * directly. We capture at least as high a quality as the export target here so
     * the export never has to upscale a lower-res capture.
     */
    private fun captureQualityFor(resolution: ResolutionOption): Quality = when (resolution) {
        ResolutionOption.P480 -> Quality.SD
        ResolutionOption.P720 -> Quality.HD
        ResolutionOption.P1080 -> Quality.FHD
        ResolutionOption.UHD4K -> Quality.UHD
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val cameraProvider = providerFuture.get()

            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(cameraPreview.surfaceProvider)
            }

            val quality = captureQualityFor(SettingsRepository.resolution)
            val recorder = Recorder.Builder()
                .setQualitySelector(
                    QualitySelector.fromOrderedList(
                        listOf(quality, Quality.FHD, Quality.HD, Quality.SD),
                        androidx.camera.video.FallbackStrategy.lowerQualityOrHigherThan(quality)
                    )
                )
                .build()
            val capture = VideoCapture.withOutput(recorder)
            videoCapture = capture

            cameraProvider.unbindAll()
            try {
                cameraProvider.bindToLifecycle(
                    this,
                    CameraSelector.DEFAULT_FRONT_CAMERA,
                    preview,
                    capture
                )
                beginRecording()
            } catch (e: Exception) {
                Log.e(TAG, "Camera bind failed", e)
                Toast.makeText(this, "Could not start the camera.", Toast.LENGTH_LONG).show()
                finish()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun beginRecording() {
        val capture = videoCapture ?: return
        val outFile = File(cacheDir, "camera_take_${System.currentTimeMillis()}.mp4")
        cameraTakeFile = outFile

        val outputOptions = FileOutputOptions.Builder(outFile).build()

        // Best-effort: route to the chosen mic (Bluetooth/wired/USB) if Settings > Audio
        // asked for one; safely does nothing if unavailable (see AudioInputHelper).
        AudioInputHelper.start(this, SettingsRepository.micSource)

        activeRecording = capture.output
            .prepareRecording(this, outputOptions)
            .withAudioEnabled()
            .start(ContextCompat.getMainExecutor(this)) { event ->
                when (event) {
                    is VideoRecordEvent.Start -> {
                        recordingStartElapsedRealtime = SystemClock.elapsedRealtime()
                        isRecordingActive = true
                        exoPlayer?.play()
                        uiHandler.post(timerTick)
                        updateRecordingBorder(true)
                    }
                    is VideoRecordEvent.Finalize -> {
                        isRecordingActive = false
                        updateRecordingBorder(false)
                        if (event.hasError()) {
                            Log.e(TAG, "Recording error: ${event.error}, ${event.cause}")
                            Toast.makeText(
                                this,
                                "Recording failed, please try again.",
                                Toast.LENGTH_LONG
                            ).show()
                            finish()
                        } else {
                            onCameraTakeFinished()
                        }
                    }
                    else -> {}
                }
            }
    }

    /**
     * "Time since recording started, according to the camera file's own (gap-free)
     * timeline" — i.e. wall-clock elapsed time minus every actual-recording pause.
     * While currently paused, this stays frozen at the moment the pause began, since
     * the camera file isn't gaining any new timeline during that time either.
     * Every timeline event this screen logs uses this, not raw wall-clock time.
     */
    private fun cameraElapsedMs(): Long {
        if (!isRecordingActive) return 0L
        val referenceNow = recordingPauseStartRealtime ?: SystemClock.elapsedRealtime()
        return (referenceNow - recordingStartElapsedRealtime) - accumulatedRecordingPauseMs
    }

    private fun togglePause() {
        val player = exoPlayer ?: return
        val elapsed = cameraElapsedMs()
        isSourcePaused = !isSourcePaused
        if (isSourcePaused) {
            player.pause()
            timeline.onPause(elapsed, player.currentPosition)
            btnPauseResume.text = "Resume Video"
        } else {
            player.play()
            timeline.onResume(elapsed, player.currentPosition)
            btnPauseResume.text = "Pause Video"
        }
    }

    private fun seekBy(deltaMs: Long) {
        val player = exoPlayer ?: return
        val duration = player.duration.coerceAtLeast(0)
        val newPos = (player.currentPosition + deltaMs).coerceIn(0, duration)
        player.seekTo(newPos)
        timeline.onSeek(cameraElapsedMs(), newPos, wasPlaying = !isSourcePaused)
    }

    /** Pauses/resumes the ENTIRE recording session (camera + mic + source video), with a resume countdown. */
    private fun toggleRecordingPause() {
        if (!isRecordingPaused) {
            isRecordingPaused = true
            recordingPauseStartRealtime = SystemClock.elapsedRealtime()
            activeRecording?.pause()
            wasSourcePlayingBeforeRecordingPause = !isSourcePaused
            exoPlayer?.pause()
            uiHandler.removeCallbacks(timerTick)
            tvRecordingPaused.visibility = android.view.View.VISIBLE
            btnPauseRecording.text = "Resume Recording"
            btnRewind.isEnabled = false
            btnForward.isEnabled = false
            btnPauseResume.isEnabled = false
            seekSourceVideo.isEnabled = false
            updateRecordingBorder(false)
        } else {
            startResumeCountdown()
        }
    }

    private fun startResumeCountdown() {
        btnPauseRecording.isEnabled = false
        tvRecordingPaused.visibility = android.view.View.GONE
        tvCountdown.visibility = android.view.View.VISIBLE
        var count = RESUME_COUNTDOWN_SECONDS

        val tick = object : Runnable {
            override fun run() {
                if (count <= 0) {
                    tvCountdown.visibility = android.view.View.GONE
                    countdownRunnable = null
                    actuallyResumeRecording()
                } else {
                    tvCountdown.text = count.toString()
                    count--
                    uiHandler.postDelayed(this, 1000)
                }
            }
        }
        countdownRunnable = tick
        uiHandler.post(tick)
    }

    private fun actuallyResumeRecording() {
        val pauseStart = recordingPauseStartRealtime
        if (pauseStart != null) {
            accumulatedRecordingPauseMs += SystemClock.elapsedRealtime() - pauseStart
        }
        recordingPauseStartRealtime = null
        isRecordingPaused = false

        activeRecording?.resume()
        if (wasSourcePlayingBeforeRecordingPause) {
            exoPlayer?.play()
        }
        uiHandler.post(timerTick)

        btnPauseRecording.text = "Pause Recording"
        btnPauseRecording.isEnabled = true
        btnRewind.isEnabled = true
        btnForward.isEnabled = true
        btnPauseResume.isEnabled = true
        seekSourceVideo.isEnabled = true
        updateRecordingBorder(true)
    }

    private fun stopEverything() {
        btnStop.isEnabled = false
        btnPauseResume.isEnabled = false
        btnRewind.isEnabled = false
        btnForward.isEnabled = false
        btnPauseRecording.isEnabled = false
        uiHandler.removeCallbacks(timerTick)
        // If Stop is tapped mid-countdown (after "Resume Recording" but before the
        // 3-2-1 finishes), cancel the pending resume — otherwise it would fire
        // Recording.resume() on a recording that's already being torn down.
        countdownRunnable?.let { uiHandler.removeCallbacks(it) }
        tvCountdown.visibility = android.view.View.GONE
        exoPlayer?.pause()

        // Remember this session's PIP layout for next time.
        if (canvasWidthPx > 0 && canvasHeightPx > 0) {
            SettingsRepository.savePipRect(pipOverlay.normalizedRectAsPipRect(recordingCanvas))
        }

        activeRecording?.stop()
    }

    private fun onCameraTakeFinished() {
        val file = cameraTakeFile ?: return
        val rect = pipOverlay.normalizedRect(recordingCanvas)

        val intent = android.content.Intent(this, ExportActivity::class.java).apply {
            putExtra(ExportActivity.EXTRA_CAMERA_TAKE_PATH, file.absolutePath)
            putExtra(ExportActivity.EXTRA_SOURCE_VIDEO_URI, sourceVideoUri)
            putExtra(ExportActivity.EXTRA_PIP_RECT, rect)
            putExtra(ExportActivity.EXTRA_TIMELINE, timeline)
        }
        startActivity(intent)
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        uiHandler.removeCallbacks(timerTick)
        uiHandler.removeCallbacks(autoHideRunnable)
        countdownRunnable?.let { uiHandler.removeCallbacks(it) }
        AudioInputHelper.stop(this, SettingsRepository.micSource)
        exoPlayer?.release()
        activeRecording?.close()
    }
}
