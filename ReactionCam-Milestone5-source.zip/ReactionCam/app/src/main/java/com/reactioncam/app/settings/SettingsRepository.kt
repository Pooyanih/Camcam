package com.reactioncam.app.settings

import android.content.Context
import android.content.SharedPreferences
import android.media.MediaFormat

enum class ResolutionOption(val refWidth: Int, val refHeight: Int, val label: String) {
    P480(854, 480, "480p"),
    P720(1280, 720, "720p"),
    P1080(1920, 1080, "1080p"),
    UHD4K(3840, 2160, "4K (UHD)")
}

enum class CodecOption(val mimeType: String, val label: String) {
    H264(MediaFormat.MIMETYPE_VIDEO_AVC, "H.264"),
    H265(MediaFormat.MIMETYPE_VIDEO_HEVC, "H.265 / HEVC")
}

enum class AspectRatioOption(val wRatio: Int, val hRatio: Int, val label: String) {
    R16_9(16, 9, "16:9 — Landscape"),
    R9_16(9, 16, "9:16 — Vertical"),
    R1_1(1, 1, "1:1 — Square"),
    R4_3(4, 3, "4:3 — Classic")
}

enum class AppTheme(
    val label: String,
    val primary: String,
    val accent: String,
    val background: String,
    val surface: String
) {
    MIDNIGHT("Midnight", "#6C5CE7", "#00CEC9", "#1C1B2E", "#26243A"),
    OCEAN("Ocean", "#0984E3", "#00CEC9", "#0B2545", "#123159"),
    EMERALD("Emerald", "#00B894", "#55EFC4", "#0B3D2E", "#12503D"),
    SUNSET("Sunset", "#E17055", "#FDCB6E", "#2D1B2E", "#3D2740")
}

enum class MicSource(val label: String) {
    DEFAULT("Phone Microphone"),
    BLUETOOTH("Bluetooth Headset"),
    WIRED("Wired Headset"),
    USB("USB Audio")
}

data class PipRect(val xFrac: Float, val yFrac: Float, val wFrac: Float, val hFrac: Float)

/** A handful of quick layouts for the PIP box's double-tap cycling. */
val PIP_PRESETS = listOf(
    PipRect(0.58f, 0.68f, 0.35f, 0.22f),  // small, bottom-right (default)
    PipRect(0.50f, 0.52f, 0.47f, 0.32f),  // medium, bottom-right
    PipRect(0.28f, 0.30f, 0.66f, 0.45f),  // large, centered
    PipRect(0.05f, 0.06f, 0.35f, 0.22f)   // small, top-left
)

/**
 * All user-configurable app settings, backed by SharedPreferences. Call [init] once
 * (any Activity's onCreate is fine — it's idempotent) before reading/writing.
 */
object SettingsRepository {
    private const val PREFS_NAME = "reactioncam_settings"
    private var prefs: SharedPreferences? = null

    fun init(context: Context) {
        if (prefs == null) {
            prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        }
    }

    private fun p(): SharedPreferences = prefs ?: error("SettingsRepository.init() was not called")

    var resolution: ResolutionOption
        get() = enumOrDefault(p().getString(KEY_RESOLUTION, null), ResolutionOption.P1080)
        set(v) = p().edit().putString(KEY_RESOLUTION, v.name).apply()

    var frameRate: Int
        get() = p().getInt(KEY_FRAME_RATE, 30)
        set(v) = p().edit().putInt(KEY_FRAME_RATE, v).apply()

    var bitrateMbps: Int
        get() = p().getInt(KEY_BITRATE, 8)
        set(v) = p().edit().putInt(KEY_BITRATE, v).apply()

    var codec: CodecOption
        get() = enumOrDefault(p().getString(KEY_CODEC, null), CodecOption.H264)
        set(v) = p().edit().putString(KEY_CODEC, v.name).apply()

    var aspectRatio: AspectRatioOption
        get() = enumOrDefault(p().getString(KEY_ASPECT, null), AspectRatioOption.R9_16)
        set(v) = p().edit().putString(KEY_ASPECT, v.name).apply()

    var theme: AppTheme
        get() = enumOrDefault(p().getString(KEY_THEME, null), AppTheme.MIDNIGHT)
        set(v) = p().edit().putString(KEY_THEME, v.name).apply()

    var pipCornerRadiusDp: Int
        get() = p().getInt(KEY_PIP_RADIUS, 16)
        set(v) = p().edit().putInt(KEY_PIP_RADIUS, v).apply()

    var pipBorderEnabled: Boolean
        get() = p().getBoolean(KEY_PIP_BORDER, false)
        set(v) = p().edit().putBoolean(KEY_PIP_BORDER, v).apply()

    /** Rewind/fast-forward step, in seconds, used by the recording screen's transport controls. */
    var seekStepSeconds: Int
        get() = p().getInt(KEY_SEEK_STEP, 10)
        set(v) = p().edit().putInt(KEY_SEEK_STEP, v).apply()

    /** Which physical input to try routing the mic recording through — see AudioInputHelper. */
    var micSource: MicSource
        get() = enumOrDefault(p().getString(KEY_MIC_SOURCE, null), MicSource.DEFAULT)
        set(v) = p().edit().putString(KEY_MIC_SOURCE, v.name).apply()

    var controlDockCompact: Boolean
        get() = p().getBoolean(KEY_DOCK_COMPACT, false)
        set(v) = p().edit().putBoolean(KEY_DOCK_COMPACT, v).apply()

    var autoHideControls: Boolean
        get() = p().getBoolean(KEY_AUTO_HIDE, false)
        set(v) = p().edit().putBoolean(KEY_AUTO_HIDE, v).apply()

    var recordingBorderEnabled: Boolean
        get() = p().getBoolean(KEY_RECORDING_BORDER, false)
        set(v) = p().edit().putBoolean(KEY_RECORDING_BORDER, v).apply()

    fun savePipRect(rect: PipRect) {
        p().edit()
            .putFloat(KEY_PIP_X, rect.xFrac).putFloat(KEY_PIP_Y, rect.yFrac)
            .putFloat(KEY_PIP_W, rect.wFrac).putFloat(KEY_PIP_H, rect.hFrac)
            .apply()
    }

    /** The last-used PIP layout, or null if the user has never recorded yet. */
    fun loadPipRect(): PipRect? {
        if (!p().contains(KEY_PIP_X)) return null
        return PipRect(
            p().getFloat(KEY_PIP_X, PIP_PRESETS[0].xFrac),
            p().getFloat(KEY_PIP_Y, PIP_PRESETS[0].yFrac),
            p().getFloat(KEY_PIP_W, PIP_PRESETS[0].wFrac),
            p().getFloat(KEY_PIP_H, PIP_PRESETS[0].hFrac)
        )
    }

    /** Rough estimate, shown on the settings screen so quality choices have a visible cost. */
    fun estimatedMbPerMinute(): Double {
        val videoKbps = bitrateMbps * 1000.0
        val audioKbps = 128.0
        return (videoKbps + audioKbps) * 60.0 / 8.0 / 1000.0
    }

    private inline fun <reified T : Enum<T>> enumOrDefault(name: String?, default: T): T {
        if (name == null) return default
        return try { enumValueOf<T>(name) } catch (e: IllegalArgumentException) { default }
    }

    private const val KEY_RESOLUTION = "resolution"
    private const val KEY_FRAME_RATE = "frame_rate"
    private const val KEY_BITRATE = "bitrate_mbps"
    private const val KEY_CODEC = "codec"
    private const val KEY_ASPECT = "aspect_ratio"
    private const val KEY_THEME = "theme"
    private const val KEY_PIP_RADIUS = "pip_corner_radius"
    private const val KEY_PIP_BORDER = "pip_border_enabled"
    private const val KEY_PIP_X = "pip_x"
    private const val KEY_PIP_Y = "pip_y"
    private const val KEY_PIP_W = "pip_w"
    private const val KEY_PIP_H = "pip_h"
    private const val KEY_SEEK_STEP = "seek_step_seconds"
    private const val KEY_MIC_SOURCE = "mic_source"
    private const val KEY_DOCK_COMPACT = "control_dock_compact"
    private const val KEY_AUTO_HIDE = "auto_hide_controls"
    private const val KEY_RECORDING_BORDER = "recording_border_enabled"

    val SEEK_STEP_OPTIONS = intArrayOf(1, 3, 5, 10, 15, 30, 45, 60)
}
