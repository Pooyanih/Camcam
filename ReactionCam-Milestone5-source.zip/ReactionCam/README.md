# ReactionCam — Milestone 1

A real, working Android app for recording reaction videos with an automatic
picture-in-picture export. No CapCut, no manual editing.

Flow: **Select Video → Record → Stop → Finished Video** (saved to your gallery, ready to share).

## How to build the APK

You need [Android Studio](https://developer.android.com/studio) (free). This project was
written outside of Android Studio (in a sandboxed environment with no Android SDK or
network access), so it has **not** been compiled or run yet — treat the first build as
step one, and see "If the first build doesn't compile" below.

1. Open Android Studio → **Open** → select the `ReactionCam` folder.
2. Let it sync Gradle (downloads dependencies the first time — needs internet).
3. Plug in an Android phone (Android 8.0 / API 26+, so this covers modern Samsung
   devices) with USB debugging on, or use **Build → Generate Signed Bundle / APK**
   to get an installable `.apk` directly.
4. Run it. Grant camera + microphone when asked, pick a video already on your phone,
   hit **Start Recording**.

## What actually happens under the hood (no mocks)

1. **Record screen** — CameraX drives the real front camera and records real camera +
   mic footage to a temp file. The source video autoplays muted in a movable/resizable
   box (drag to move, drag the bottom-right corner handle to resize) on top of the live
   preview, rendered with a `TextureView` so it composites correctly on top of the
   camera's own preview surface. Rewind 10s / Pause / Forward 10s all work mid-recording,
   and every tap is timestamped into a `PlaybackTimeline`.
2. **Stop** — the camera recording finalizes.
3. **Export screen** — a GPU compositor (OpenGL + `MediaCodec`) decodes both videos
   frame by frame, draws the camera footage full-screen and the source video into the
   PiP box you positioned, **freezing/relocating the PiP layer exactly per your
   pauses, rewinds and fast-forwards**, and encodes one real MP4. In parallel, your
   mic audio and the source video's own audio are decoded, mixed together (source
   ducked slightly behind your mic), and re-encoded as the final AAC track — both are
   audible in the finished video.
4. The finished file is inserted into `MediaStore` (Movies/ReactionCam), so it shows up
   in your gallery immediately and is shareable via the normal Android share sheet.

## Milestone 2 — Look & Layout + Quality & Format

Two feature groups added on top of Milestone 1:

**Look & Layout**
- The PIP box's position/size is now remembered between recordings (SharedPreferences), and applied automatically next time you record.
- Double-tap the PIP box to cycle through four quick preset layouts.
- Corner roundness and an optional border are configurable in Settings, and are genuinely baked into the exported video (not just a screen overlay) via a rounded-rect shader in `GlUtil.kt`.
- Four themes (Midnight, Ocean, Emerald, Sunset) restyle Main/Settings/Export screens via a real Android attr-based theme system (`attrs.xml` + `themes.xml`), plus a lighter tint pass on the recording screen's controls.

**Quality & Format**
- Resolution (480p/720p/1080p/4K), frame rate (15/24/30/60fps), bitrate (1–30 Mbps), codec (H.264/H.265), and aspect ratio (16:9/9:16/1:1/4:3) are all set in Settings and **genuinely applied to the final exported file** — that whole pipeline is raw `MediaCodec` I control directly, so these aren't cosmetic toggles.
- A live size estimate (MB/minute) updates as you adjust resolution/bitrate.
- The recording screen's camera preview is now letterboxed to match your chosen aspect ratio, so what you frame matches what you get.

**One honest architectural note**: CameraX's stable `Recorder` API (used for the *live capture* of your camera+mic) doesn't expose arbitrary resolutions, precise frame rates, or codec choice — those are mapped to the closest available capture preset instead (see the comment above `captureQualityFor` in `RecordActivity.kt`). The frame rate/codec/resolution/bitrate settings you actually chose are all correctly applied to the file that gets saved and shared, since the export/compositing stage is a separate, fully custom `MediaCodec` pipeline with no such limitation. Getting exact control over live capture too would mean replacing CameraX's `Recorder` with a raw Camera2 + `MediaCodec` capture pipeline — a bigger change, and a reasonable candidate for a future milestone if it matters to you.

## Milestone 3 — Recording Complete screen + real playback controls

**Recording Complete screen** — Stop no longer dumps you straight into a saved file. You get a thumbnail, an editable filename (defaults to `Reaction_yyyy-MM-dd_HH-mm`), and:
- **Preview** / **Share** — work immediately on the temp file (via a `FileProvider`), even before you save.
- **Save to Gallery** — writes the file to `MediaStore` under your (possibly renamed) filename.
- **Open in Gallery** — enabled once saved.
- **Delete** — removes the temp file (or the saved one, with confirmation) without ever touching your gallery.
- Leaving without saving prompts a confirmation so a recording is never silently lost.

**Real playback controls**
- A scrub bar under the recording screen shows live position and lets you drag to seek — logged into the same timeline as Rewind/Forward, so scrubbing mid-recording is reflected correctly in the export.
- Rewind/forward step is now a Settings choice (1/3/5/10/15/30/45/60s) instead of a fixed 10s.
- **Pause Recording** (distinct from "Pause Video") pauses the actual camera+mic capture via CameraX's own `Recording.pause()`/`resume()` — the output file has no gap or frozen frame for that time, it's simply excluded, exactly like a real camcorder's pause button. Resuming shows a 3-2-1 countdown before capture actually continues. Rewinding/scrubbing the source video works fine independently before or after a recording pause — the two pause concepts don't interfere with each other's bookkeeping (see the class-level comment in `RecordActivity.kt` on `cameraElapsedMs()` if you're curious how that's kept in sync).

## Milestone 4 — Audio input, recording border, auto-hide, compact dock

**Audio input selection** — Settings > Audio lists whichever mic inputs are actually available right now (phone mic always; Bluetooth/wired/USB show up automatically once connected) and tries to route recording through your choice via `AudioManager` (the modern `setCommunicationDevice` API on Android 12+, classic Bluetooth SCO calls below that). This is the one piece of this milestone I couldn't verify against real Bluetooth/USB hardware in the build environment — see the disclaimer at the top of `AudioInputHelper.kt`. It's built defensively: if routing to the chosen device fails for any reason, recording proceeds on the default mic rather than breaking.

**Recording border** — an optional on-screen accent-colored border around the recording area, visible only while actively capturing (auto-hides during an actual-recording pause). Purely a screen indicator, like the spec asked for — never baked into the exported file.

**Auto-hide controls** — after 3.5s of inactivity, the timer chip, source-position chip, and bottom control dock fade out; tapping the camera view brings them right back.

**Compact / transparent control dock** — shrinks the transport buttons and adds transparency, so they get out of the way of framing your shot.

**A note on "fullscreen recording mode"**: in the original spec this was about keeping app UI out of the *recorded* video. That's a non-issue here by construction — the export is composited straight from the camera + PIP feeds via `MediaCodec`/OpenGL, never a screen recording of the app itself, so on-screen buttons were never going to appear in your file regardless of visibility. Auto-hide above covers the actual practical want (an uncluttered viewfinder) without needing to "protect" anything.

**Deferred**: device rotation / landscape recording capture (the app is locked to portrait capture; the aspect-ratio cropping already covers most of the practical need for vertical/square/4:3 output without it) — flagging it as a real architecture item if it turns out to matter, rather than bolting on a shallow version.

## Milestone 5 — Smoothness & bug-fix pass

No new features this round — a deliberate stop to review everything already built before you compile a "final" version, specifically for two things: making sure recording stays smooth, and finding anything half-finished before it ships.

**Fixed, real bugs (not cosmetic):**
- **PIP resize stutter** — dragging the PIP box's resize handle was allocating a brand-new `GradientDrawable` on every single frame of the drag (`onSizeChanged` fired continuously during resize). That's exactly the kind of GC churn that shows up as visible stutter while you're actively resizing mid-recording. Fixed by mutating one cached drawable's corner radius in place instead of reallocating (`PipOverlayView.kt`).
- **Recording Complete freeze** — thumbnail generation (`MediaMetadataRetriever`, decoding a video frame) was running synchronously on the UI thread right as that screen appeared. Moved to the background export thread alongside the compositor work it was already sitting next to.
- **Crash risk: Stop during the resume countdown** — tapping Stop while the 3-2-1 "resuming…" countdown was still running left a pending `Recording.resume()` call scheduled, which would fire on a recording that's already being torn down. The countdown is now cancelable and gets cancelled the moment Stop is pressed (`RecordActivity.kt`).
- **Save/Delete UI freezes** — "Save to Gallery" was copying the whole finished file (which can be tens or hundreds of MB) synchronously on the button-tap thread. Both Save and Delete now run their file I/O on a background thread with a proper "Saving…" state in between.

**On "make sure recording doesn't get laggy" specifically**: the fixes above remove software-side stutter I could actually find and verify by reading the code carefully. What I can't fix from here, because it depends on your specific phone, is hardware contention — decoding the source video for the PIP preview while simultaneously encoding the camera recording is two concurrent hardware video sessions, and very old or low-end devices can strain under that combination regardless of how clean the app code is. If you do see lag on your device, the first thing to try is lowering Resolution and/or Bitrate in Settings > Quality & Format — that reduces the camera encoder's real workload, not just the exported file's.

## Known limitations (by design, to ship something complete first)

- The PiP box's position/size is captured **once, at the moment you hit Stop**, and
  used as a single static rect for the whole export. It does not yet animate if you
  moved it mid-recording. (See "Next milestones" — this is a small, isolated change.)
- The source video's audio is mixed in at a fixed lower volume behind your mic
  (currently 50%, set in `VideoCompositor`'s call to `AudioMixer.mixAndEncode`) — not
  yet a user-adjustable slider.
- Orientation handling (front camera + source video rotation metadata) is implemented
  correctly per the standard Android APIs, but could not be verified on real hardware
  in the environment this was built in (no device/emulator access). If a specific
  Samsung device ever renders sideways or mirrored, the fix is a one-line sign flip in
  `GlUtil.kt`'s `buildTexMatrix` call sites — flag it and it's a quick patch.
- No trimming, captions, or intro screens yet — intentionally deferred, see roadmap.

## Architecture, for future milestones

- `MainActivity` — picker + permissions only.
- `RecordActivity` — live capture: CameraX + ExoPlayer + `PipOverlayView` (drag/resize)
  + `PauseLog` (timestamps).
- `export/` — the entire compositing engine, independent of the UI:
  - `PauseLog.kt` — maps "camera timeline" → "source video virtual timeline",
    handling freezes. This is the one class that encodes the pause/resume rule.
  - `VideoTrackDecoder.kt` — steps one video track forward, frame by frame.
  - `GlUtil.kt` — EGL/shader plumbing; `buildTexMatrix` handles rotation + crop.
  - `VideoCompositor.kt` — orchestrates both decoders + the encoder + the muxer.
- `ExportActivity` — runs `VideoCompositor` on a background thread with a progress
  callback, then saves to `MediaStore` and shows Play/Share.

This split is deliberate so each of these later features is additive, not a rewrite:

| Feature                     | Where it plugs in                                             |
|------------------------------|----------------------------------------------------------------|
| Moving the overlay position  | Replace the single `pipRectNormalized` with a list of timed keyframes; interpolate per-frame in `VideoCompositor`'s render loop. |
| Trimming                     | Change the extractor seek range / start-stop pts fed into the render loop. |
| Captions                     | A third draw call (text rendered to a texture, or a simple canvas overlay bitmap) in the same render loop. |
| Intro screen                 | Render a few seconds of a static/title frame before the main loop starts, same encoder/muxer. |
| Recording settings (quality, camera choice, PiP shape) | Isolated to `RecordActivity`'s CameraX setup and `PipOverlayView`; export code doesn't change. |

## Building without a PC (from your phone) — easiest way, browser only

No Termux, no git, no command line, no token — just GitHub's website in your phone's
browser, three steps.

1. **Create the repo and upload the zip as-is.**
   - Go to github.com on your phone, sign up or log in.
   - Tap **New repository** → give it a name (e.g. `ReactionCam`) → leave it **empty**
     (don't add a README) → **Create repository**.
   - On the new repo's page, tap **Add file → Upload files**, then pick the
     `ReactionCam-Milestone1-source.zip` you downloaded from this chat (from your
     Downloads). Don't unzip it — upload the zip itself. Tap **Commit changes**.
2. **Add the build recipe.**
   - Tap **Add file → Create new file**.
   - In the filename box, type the full path: `.github/workflows/build-apk.yml`
     (typing the slashes creates the folders automatically).
   - Paste in the contents of that same file from the project (open the zip's
     `.github/workflows/build-apk.yml` in any text viewer to copy it, or ask me and
     I'll paste it here for you to copy directly).
   - Tap **Commit changes**.
3. **Get your APK.**
   - Tap the **Actions** tab at the top of your repo. A build should already be
     running (triggered by your commit) — tap it to watch progress, it takes a few
     minutes.
   - When it finishes with a green check, scroll down to **Artifacts** and download
     `ReactionCam-debug-apk` (a small zip containing the `.apk`).
   - Open that zip with your phone's file manager, extract the `.apk`, tap it, allow
     "install unknown apps" if asked. Done.

The workflow automatically detects the uploaded zip and unpacks it before building, so
you never had to extract anything yourself.

## Building without a PC — the Termux/git way (more control, more steps)

You can have GitHub's servers build the APK for you — your phone only needs to push
the code and download the result. This repo already includes the build recipe at
`.github/workflows/build-apk.yml`.

1. **Get the code onto GitHub** (needs a real git client, not just the browser upload
   button, since that can't preserve this project's folder structure):
   - Install **Termux** from F-Droid (not the outdated Play Store version):
     https://f-droid.org/packages/com.termux/
   - In Termux: `pkg install git` then `termux-setup-storage` (grants access to your
     Downloads folder).
   - Extract the zip you downloaded from this chat somewhere in your phone's storage
     (most file manager apps can unzip; if not, `pkg install unzip` in Termux and run
     `unzip ~/storage/downloads/ReactionCam-*.zip -d ~/ReactionCam`).
   - Create a free account at github.com and a new **empty** repository (no README).
   - Create a GitHub Personal Access Token (github.com → Settings → Developer settings
     → Personal access tokens → generate one with "repo" scope) — you'll use it as
     your password when pushing.
   - In Termux:
     ```
     cd ~/ReactionCam        # or wherever you unzipped it
     git init
     git add .
     git commit -m "Initial commit"
     git branch -M main
     git remote add origin https://github.com/<your-username>/<your-repo>.git
     git push -u origin main
     ```
     When prompted for a password, paste the token.
2. **Let GitHub build it**: pushing automatically triggers the workflow. On your
   phone's browser, go to your repo → **Actions** tab → open the running/completed
   workflow → scroll to **Artifacts** → download `ReactionCam-debug-apk` (a small zip
   containing the `.apk`).
3. **Install it**: open the downloaded zip with your phone's file manager, extract the
   `.apk`, tap it, and allow "install unknown apps" for your browser/file manager when
   asked. That's it — no PC involved at any point.

If a future milestone adds new files, the same `git add . && git commit && git push`
three-liner rebuilds it automatically — you don't need to touch the workflow again.


This was authored carefully against the current stable CameraX (1.3.4), Media3 (1.4.1)
and AGP (8.5.2) APIs, but wasn't compiled in this environment (no SDK/network access
there). If Android Studio flags anything, paste the error back and it's a fast, targeted
fix — the architecture above won't need to change.
