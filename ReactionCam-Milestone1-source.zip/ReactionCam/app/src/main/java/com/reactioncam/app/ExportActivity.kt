package com.reactioncam.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.reactioncam.app.export.PauseLog
import com.reactioncam.app.export.VideoCompositor
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Runs [VideoCompositor] off the UI thread, shows a simple progress screen, then a
 * finished screen with Play / Share / Back to Home — the last step of the
 * "Select Video -> Record -> Stop -> Finished Video" flow.
 */
class ExportActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_CAMERA_TAKE_PATH = "extra_camera_take_path"
        const val EXTRA_SOURCE_VIDEO_URI = "extra_source_video_uri"
        const val EXTRA_PIP_RECT = "extra_pip_rect"
        const val EXTRA_PAUSE_LOG = "extra_pause_log"
        private const val TAG = "ExportActivity"
    }

    private var finishedUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_export)

        val cameraTakePath = intent.getStringExtra(EXTRA_CAMERA_TAKE_PATH)
        @Suppress("DEPRECATION")
        val sourceUri = intent.getParcelableExtra<Uri>(EXTRA_SOURCE_VIDEO_URI)
        val pipRect = intent.getFloatArrayExtra(EXTRA_PIP_RECT)
        @Suppress("DEPRECATION")
        val pauseLog = intent.getSerializableExtra(EXTRA_PAUSE_LOG) as? PauseLog

        if (cameraTakePath == null || sourceUri == null || pipRect == null || pauseLog == null) {
            Toast.makeText(this, "Something went wrong preparing your video.", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        startExport(File(cameraTakePath), sourceUri, pipRect, pauseLog)
    }

    private fun startExport(cameraTake: File, sourceUri: Uri, pipRect: FloatArray, pauseLog: PauseLog) {
        val outFile = File(cacheDir, "reaction_export_${System.currentTimeMillis()}.mp4")

        Thread {
            try {
                val compositor = VideoCompositor(
                    context = applicationContext,
                    cameraTakeFile = cameraTake,
                    sourceVideoUri = sourceUri,
                    pipRectNormalized = pipRect,
                    pauseLog = pauseLog,
                    outputFile = outFile,
                    onProgress = { progress ->
                        runOnUiThread { updateProgress(progress) }
                    }
                )
                compositor.run()

                val name = "ReactionCam_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.mp4"
                val savedUri = MediaStoreUtil.saveVideoToGallery(applicationContext, outFile, name)
                outFile.delete()
                cameraTake.delete()

                runOnUiThread {
                    if (savedUri != null) {
                        finishedUri = savedUri
                        showFinished()
                    } else {
                        showError("Could not save the video to your gallery.")
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Export failed", e)
                runOnUiThread { showError("Export failed: ${e.message}") }
            }
        }.start()
    }

    private fun updateProgress(progress: Float) {
        findViewById<TextView>(R.id.tvProgressPercent).text = "${(progress * 100).toInt()}%"
    }

    private fun showError(message: String) {
        findViewById<TextView>(R.id.tvStatus).text = message
        findViewById<android.widget.ProgressBar>(R.id.progressBar).visibility = android.view.View.GONE
    }

    private fun showFinished() {
        findViewById<android.widget.ProgressBar>(R.id.progressBar).visibility = android.view.View.GONE
        findViewById<TextView>(R.id.tvStatus).visibility = android.view.View.GONE
        findViewById<TextView>(R.id.tvProgressPercent).visibility = android.view.View.GONE
        findViewById<android.widget.LinearLayout>(R.id.doneLayout).visibility = android.view.View.VISIBLE

        findViewById<Button>(R.id.btnPlay).setOnClickListener {
            val uri = finishedUri ?: return@setOnClickListener
            startActivity(Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "video/mp4")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            })
        }
        findViewById<Button>(R.id.btnShare).setOnClickListener {
            val uri = finishedUri ?: return@setOnClickListener
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = "video/mp4"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }, "Share reaction video"))
        }
        findViewById<Button>(R.id.btnDone).setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
            })
            finish()
        }
    }
}
