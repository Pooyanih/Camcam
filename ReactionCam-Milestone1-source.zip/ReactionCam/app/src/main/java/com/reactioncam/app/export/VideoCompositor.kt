package com.reactioncam.app.export

import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import java.io.File

/**
 * Renders the final reaction video: camera take as the full-screen main layer, source
 * video as a picture-in-picture overlay positioned per [pipRectNormalized], frozen
 * during every interval in [pauseLog]. This runs entirely offline (not real-time), so
 * there is no risk of dropped frames under load — it's exactly as fast as the
 * device's hardware codecs allow, typically a few times faster than the clip's own
 * length.
 *
 * Architecture note for future milestones: [pipRectNormalized] is a single static
 * rect for the whole video. To support an animated/keyframed overlay position later,
 * replace the single rect with a list of (timeMs -> rect) keyframes and interpolate
 * per main frame inside the render loop below — everything else stays the same.
 */
class VideoCompositor(
    private val context: Context,
    private val cameraTakeFile: File,
    private val sourceVideoUri: Uri,
    private val pipRectNormalized: FloatArray, // x, y, w, h as fractions of the canvas
    private val pauseLog: PauseLog,
    private val outputFile: File,
    private val onProgress: (Float) -> Unit
) {
    fun run() {
        val mainExtractor = MediaExtractor().apply { setDataSource(cameraTakeFile.absolutePath) }
        val overlayExtractor = MediaExtractor().apply {
            context.contentResolver.openFileDescriptor(sourceVideoUri, "r")?.use { pfd ->
                setDataSource(pfd.fileDescriptor)
            } ?: error("Could not open source video")
        }
        val audioExtractor = MediaExtractor().apply { setDataSource(cameraTakeFile.absolutePath) }

        val mainVideoTrack = findTrack(mainExtractor, "video/") ?: error("No video track in camera take")
        val overlayVideoTrack = findTrack(overlayExtractor, "video/") ?: error("No video track in source video")
        val audioTrack = findTrack(audioExtractor, "audio/")

        val mainFormat = mainExtractor.getTrackFormat(mainVideoTrack)
        val overlayFormat = overlayExtractor.getTrackFormat(overlayVideoTrack)

        val mainRotation = readRotationDegrees(cameraTakeFile.absolutePath, null)
        val overlayRotation = readRotationDegrees(null, sourceVideoUri)

        val mainRawW = mainFormat.getInteger(MediaFormat.KEY_WIDTH)
        val mainRawH = mainFormat.getInteger(MediaFormat.KEY_HEIGHT)
        val canvasWidth = if (mainRotation == 90 || mainRotation == 270) mainRawH else mainRawW
        val canvasHeight = if (mainRotation == 90 || mainRotation == 270) mainRawW else mainRawH

        val overlayRawW = overlayFormat.getInteger(MediaFormat.KEY_WIDTH)
        val overlayRawH = overlayFormat.getInteger(MediaFormat.KEY_HEIGHT)
        val overlayW = if (overlayRotation == 90 || overlayRotation == 270) overlayRawH else overlayRawW
        val overlayH = if (overlayRotation == 90 || overlayRotation == 270) overlayRawW else overlayRawH
        val overlayAspect = overlayW.toFloat() / overlayH.toFloat()

        val durationUs = if (mainFormat.containsKey(MediaFormat.KEY_DURATION)) {
            mainFormat.getLong(MediaFormat.KEY_DURATION)
        } else 1L

        // --- Encoder setup ---
        val outputFormat = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, canvasWidth, canvasHeight).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, (canvasWidth * canvasHeight * 6).coerceAtLeast(4_000_000))
            setInteger(MediaFormat.KEY_FRAME_RATE, 30)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
        }
        val encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        encoder.configure(outputFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val encoderInputSurface = encoder.createInputSurface()
        encoder.start()

        val eglSurface = EncoderEglSurface(encoderInputSurface)
        eglSurface.setup()

        val quadProgram = OesQuadProgram()
        quadProgram.setup()

        val mainTexture = FrameTexture()
        val overlayTexture = FrameTexture()

        val mainDecoder = VideoTrackDecoder(mainExtractor, mainVideoTrack, mainTexture.surface)
        val overlayDecoder = VideoTrackDecoder(overlayExtractor, overlayVideoTrack, overlayTexture.surface)

        val muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var muxerVideoTrack = -1
        var muxerAudioTrack = -1
        var muxerStarted = false
        val bufferInfo = MediaCodec.BufferInfo()

        fun drainEncoder(endOfStream: Boolean) {
            if (endOfStream) encoder.signalEndOfInputStream()
            while (true) {
                val outIdx = encoder.dequeueOutputBuffer(bufferInfo, if (endOfStream) 10_000 else 0)
                when {
                    outIdx == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                        if (!endOfStream) return
                    }
                    outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        check(!muxerStarted) { "Encoder format changed twice" }
                        muxerVideoTrack = muxer.addTrack(encoder.outputFormat)
                        if (audioTrack != null) {
                            muxerAudioTrack = muxer.addTrack(audioExtractor.getTrackFormat(audioTrack))
                        }
                        muxer.start()
                        muxerStarted = true
                    }
                    outIdx >= 0 -> {
                        val encodedData = encoder.getOutputBuffer(outIdx)
                        if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) {
                            bufferInfo.size = 0
                        }
                        if (bufferInfo.size != 0 && encodedData != null && muxerStarted) {
                            encodedData.position(bufferInfo.offset)
                            encodedData.limit(bufferInfo.offset + bufferInfo.size)
                            muxer.writeSampleData(muxerVideoTrack, encodedData, bufferInfo)
                        }
                        val isEos = bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                        encoder.releaseOutputBuffer(outIdx, false)
                        if (isEos) return
                    }
                }
            }
        }

        // --- Main render loop: paced by the camera track's own frames ---
        while (true) {
            eglSurface.makeCurrent()
            val mainPtsUs = mainDecoder.decodeNextFrame(mainTexture) ?: break

            val sourceVirtualMs = pauseLog.mapToSourceTimeMs(mainPtsUs / 1000)
            if (!overlayDecoder.outputEos) {
                overlayDecoder.advanceTo(sourceVirtualMs * 1000, overlayTexture)
            }

            // Main layer: full canvas, no crop (assume matching aspect after rotation fix).
            val mainMatrix = buildTexMatrix(
                mainTexture.getTransformMatrix(), mainRotation, applyCrop = false,
                srcAspect = canvasWidth.toFloat() / canvasHeight, dstAspect = canvasWidth.toFloat() / canvasHeight
            )
            quadProgram.draw(mainTexture.textureId, mainMatrix, 0, 0, canvasWidth, canvasHeight)

            // Overlay (PiP) layer: center-cropped into its rect.
            val pipX = (pipRectNormalized[0] * canvasWidth).toInt()
            val pipYTop = (pipRectNormalized[1] * canvasHeight).toInt()
            val pipW = (pipRectNormalized[2] * canvasWidth).toInt().coerceAtLeast(2)
            val pipH = (pipRectNormalized[3] * canvasHeight).toInt().coerceAtLeast(2)
            // GL viewport origin is bottom-left; our rect was captured top-left-origin.
            val pipYGl = canvasHeight - pipYTop - pipH

            val overlayMatrix = buildTexMatrix(
                overlayTexture.getTransformMatrix(), overlayRotation, applyCrop = true,
                srcAspect = overlayAspect, dstAspect = pipW.toFloat() / pipH
            )
            quadProgram.draw(overlayTexture.textureId, overlayMatrix, pipX, pipYGl, pipW, pipH)

            eglSurface.setPresentationTimeNs(mainPtsUs * 1000)
            eglSurface.swapBuffers()

            drainEncoder(endOfStream = false)
            onProgress((mainPtsUs.toFloat() / durationUs.toFloat()).coerceIn(0f, 1f))
        }

        drainEncoder(endOfStream = true)

        // --- Remux mic audio straight through (already AAC-encoded by CameraX; no re-encode needed) ---
        if (audioTrack != null && muxerAudioTrack >= 0) {
            val buffer = java.nio.ByteBuffer.allocate(1 shl 20)
            val info = MediaCodec.BufferInfo()
            while (true) {
                val size = audioExtractor.readSampleData(buffer, 0)
                if (size < 0) break
                info.offset = 0
                info.size = size
                info.presentationTimeUs = audioExtractor.sampleTime
                info.flags = audioExtractor.sampleFlags
                muxer.writeSampleData(muxerAudioTrack, buffer, info)
                audioExtractor.advance()
            }
        }

        muxer.stop()
        muxer.release()
        encoder.stop()
        encoder.release()
        mainDecoder.release()
        overlayDecoder.release()
        mainTexture.release()
        overlayTexture.release()
        eglSurface.release()
        mainExtractor.release()
        overlayExtractor.release()
        audioExtractor.release()
        onProgress(1f)
    }

    private fun findTrack(extractor: MediaExtractor, mimePrefix: String): Int? {
        for (i in 0 until extractor.trackCount) {
            val mime = extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith(mimePrefix)) return i
        }
        return null
    }

    private fun readRotationDegrees(path: String?, uri: Uri?): Int {
        val retriever = MediaMetadataRetriever()
        return try {
            if (path != null) retriever.setDataSource(path) else retriever.setDataSource(context, uri!!)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
        } catch (_: Exception) {
            0
        } finally {
            retriever.release()
        }
    }
}
