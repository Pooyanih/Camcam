package com.reactioncam.app

import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import com.reactioncam.app.export.PauseLog
import java.io.File
import java.util.Locale

/**
 * Fullscreen recording screen. Front camera fills the background (CameraX), the
 * source video autoplays muted in a movable/resizable PipOverlayView, and every
 * pause/resume tap is timestamped into a PauseLog. The camera take (with mic audio)
 * is recorded to a temp file; the actual PiP compositing happens afterwards in
 * ExportActivity so pause/resume correctness doesn't depend on real-time GL timing.
 */
class RecordActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_SOURCE_VIDEO_URI = "extra_source_video_uri"
        private const val TAG = "RecordActivity"
    }

    private lateinit var cameraPreview: PreviewView
    private lateinit var pipOverlay: PipOverlayView
    private lateinit var btnPauseResume: Button
    private lateinit var btnStop: Button
    private lateinit var tvTimer: TextView

    private lateinit var sourceVideoUri: Uri
    private var exoPlayer: ExoPlayer? = null

    private var videoCapture: VideoCapture<Recorder>? = null
    private var activeRecording: Recording? = null
    private var cameraTakeFile: File? = null

    private var recordingStartElapsedRealtime = 0L
    private val pauseLog = PauseLog()
    private var isSourcePaused = false

    private val uiHandler = Handler(Looper.getMainLooper())
    private val timerTick = object : Runnable {
        override fun run() {
            val elapsed = SystemClock.elapsedRealtime() - recordingStartElapsedRealtime
            val totalSeconds = elapsed / 1000
            tvTimer.text = String.format(Locale.US, "%02d:%02d", totalSeconds / 60, totalSeconds % 60)
            uiHandler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_record)

        sourceVideoUri = intent.getParcelableExtra(EXTRA_SOURCE_VIDEO_URI)
            ?: run {
                Toast.makeText(this, "No source video provided", Toast.LENGTH_LONG).show()
                finish()
                return
            }

        cameraPreview = findViewById(R.id.cameraPreview)
        pipOverlay = findViewById(R.id.pipOverlay)
        btnPauseResume = findViewById(R.id.btnPauseResume)
        btnStop = findViewById(R.id.btnStop)
        tvTimer = findViewById(R.id.tvTimer)

        setupSourcePlayer()
        startCamera()

        btnPauseResume.setOnClickListener { togglePause() }
        btnStop.setOnClickListener { stopEverything() }
    }

    private fun setupSourcePlayer() {
        val player = ExoPlayer.Builder(this).build().apply {
            setMediaItem(MediaItem.fromUri(sourceVideoUri))
            volume = 0f // Only mic audio is captured; source video plays silently as a visual guide.
            repeatMode = ExoPlayer.REPEAT_MODE_OFF
            playWhenReady = false
            prepare()
        }
        exoPlayer = player
        pipOverlay.playerView.player = player
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val cameraProvider = providerFuture.get()

            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(cameraPreview.surfaceProvider)
            }

            val recorder = Recorder.Builder()
                .setQualitySelector(QualitySelector.from(Quality.FHD))
                .build()
            val capture = VideoCapture.withOutput(recorder)
            videoCapture = capture

            cameraProvider.unbindAll()
            try {
                cameraProvider.bindToLifecycle(
                    this,
                    CameraSelector.DEFAULT_FRONT_CAMERA,
                    preview,
                    capture
                )
                beginRecording()
            } catch (e: Exception) {
                Log.e(TAG, "Camera bind failed", e)
                Toast.makeText(this, "Could not start the camera.", Toast.LENGTH_LONG).show()
                finish()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun beginRecording() {
        val capture = videoCapture ?: return
        val outFile = File(cacheDir, "camera_take_${System.currentTimeMillis()}.mp4")
        cameraTakeFile = outFile

        val outputOptions = FileOutputOptions.Builder(outFile).build()

        activeRecording = capture.output
            .prepareRecording(this, outputOptions)
            .withAudioEnabled()
            .start(ContextCompat.getMainExecutor(this)) { event ->
                when (event) {
                    is VideoRecordEvent.Start -> {
                        recordingStartElapsedRealtime = SystemClock.elapsedRealtime()
                        exoPlayer?.play()
                        uiHandler.post(timerTick)
                    }
                    is VideoRecordEvent.Finalize -> {
                        if (event.hasError()) {
                            Log.e(TAG, "Recording error: ${event.error}, ${event.cause}")
                            Toast.makeText(
                                this,
                                "Recording failed, please try again.",
                                Toast.LENGTH_LONG
                            ).show()
                            finish()
                        } else {
                            onCameraTakeFinished()
                        }
                    }
                    else -> {}
                }
            }
    }

    private fun togglePause() {
        val elapsed = SystemClock.elapsedRealtime() - recordingStartElapsedRealtime
        isSourcePaused = !isSourcePaused
        if (isSourcePaused) {
            exoPlayer?.pause()
            pauseLog.onPause(elapsed)
            btnPauseResume.text = "Resume Video"
        } else {
            exoPlayer?.play()
            pauseLog.onResume(elapsed)
            btnPauseResume.text = "Pause Video"
        }
    }

    private fun stopEverything() {
        btnStop.isEnabled = false
        btnPauseResume.isEnabled = false
        val finalElapsed = SystemClock.elapsedRealtime() - recordingStartElapsedRealtime
        pauseLog.closeOpenInterval(finalElapsed)
        uiHandler.removeCallbacks(timerTick)
        exoPlayer?.pause()
        activeRecording?.stop()
    }

    private fun onCameraTakeFinished() {
        val file = cameraTakeFile ?: return
        val rect = pipOverlay.normalizedRect(cameraPreview)

        val intent = android.content.Intent(this, ExportActivity::class.java).apply {
            putExtra(ExportActivity.EXTRA_CAMERA_TAKE_PATH, file.absolutePath)
            putExtra(ExportActivity.EXTRA_SOURCE_VIDEO_URI, sourceVideoUri)
            putExtra(ExportActivity.EXTRA_PIP_RECT, rect)
            putExtra(ExportActivity.EXTRA_PAUSE_LOG, pauseLog)
        }
        startActivity(intent)
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        uiHandler.removeCallbacks(timerTick)
        exoPlayer?.release()
        activeRecording?.close()
    }
}
