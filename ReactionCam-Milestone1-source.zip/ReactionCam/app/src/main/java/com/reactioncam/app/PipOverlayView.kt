package com.reactioncam.app

import android.content.Context
import android.graphics.Color
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.media3.ui.PlayerView
import kotlin.math.max

/**
 * A movable, resizable box that hosts the source-video PlayerView on top of the
 * fullscreen camera preview. Drag anywhere on the box to move it; drag the bottom-right
 * handle to resize it. Position/size are plain view properties (x, y, width, height)
 * so RecordActivity can read the final rect at Stop time and hand it to the exporter,
 * which converts it to a fraction of the camera frame so it renders correctly
 * regardless of screen size vs. output video resolution.
 */
class PipOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    val playerView: PlayerView = PlayerView(context).apply {
        useController = false
        // Center-crop, matching the export compositor's overlay scaling so what you
        // see while recording is what ends up in the finished video.
        resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM
        layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
    }

    private val handleSizePx = (20 * resources.displayMetrics.density).toInt()
    private val handle = View(context).apply {
        setBackgroundColor(Color.parseColor("#CCFFFFFF"))
    }

    private val minSizePx = (80 * resources.displayMetrics.density).toInt()

    private var mode = Mode.NONE
    private var lastRawX = 0f
    private var lastRawY = 0f
    private var startWidth = 0
    private var startHeight = 0

    private enum class Mode { NONE, DRAG, RESIZE }

    init {
        setBackgroundColor(Color.parseColor("#33000000"))
        addView(playerView)
        addView(handle, LayoutParams(handleSizePx, handleSizePx, android.view.Gravity.BOTTOM or android.view.Gravity.END))
        isClickable = true
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val parentView = parent as? ViewGroup ?: return super.onTouchEvent(event)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastRawX = event.rawX
                lastRawY = event.rawY
                startWidth = width
                startHeight = height
                val local = floatArrayOf(event.x, event.y)
                mode = if (local[0] >= width - handleSizePx * 1.5f && local[1] >= height - handleSizePx * 1.5f) {
                    Mode.RESIZE
                } else {
                    Mode.DRAG
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - lastRawX
                val dy = event.rawY - lastRawY
                when (mode) {
                    Mode.DRAG -> {
                        val newX = (x + dx).coerceIn(0f, (parentView.width - width).toFloat())
                        val newY = (y + dy).coerceIn(0f, (parentView.height - height).toFloat())
                        x = newX
                        y = newY
                    }
                    Mode.RESIZE -> {
                        val newWidth = max(minSizePx, (startWidth + dx).toInt())
                            .coerceAtMost(parentView.width - x.toInt())
                        val newHeight = max(minSizePx, (startHeight + dy).toInt())
                            .coerceAtMost(parentView.height - y.toInt())
                        val lp = layoutParams
                        lp.width = newWidth
                        lp.height = newHeight
                        layoutParams = lp
                    }
                    Mode.NONE -> {}
                }
                lastRawX = event.rawX
                lastRawY = event.rawY
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                mode = Mode.NONE
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    /**
     * Rect of this box relative to [container]'s coordinate space, as fractions (0..1).
     * Used by the exporter to place the PiP overlay at the same relative position/size
     * in the final rendered video, regardless of the recording screen's pixel dimensions.
     */
    fun normalizedRect(container: View): FloatArray {
        val cw = container.width.toFloat().coerceAtLeast(1f)
        val ch = container.height.toFloat().coerceAtLeast(1f)
        return floatArrayOf(x / cw, y / ch, width / cw, height / ch)
    }
}
