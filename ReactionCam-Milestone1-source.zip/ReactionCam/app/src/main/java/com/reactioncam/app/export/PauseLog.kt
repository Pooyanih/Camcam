package com.reactioncam.app.export

import java.io.Serializable

/**
 * One paused interval of the source video, in milliseconds elapsed since the camera
 * recording started. [endMs] is -1 if the pause was still active when Stop was pressed
 * (the caller fills it in with the final elapsed time at stop).
 */
data class PauseInterval(val startMs: Long, var endMs: Long) : Serializable

/**
 * Full pause/resume history for one take. This is the single source of truth the
 * exporter uses to decide, for any point in the camera recording's timeline, what the
 * source video's "virtual" playback position should be (i.e. it freezes advancing
 * while paused, then continues from where it left off on resume).
 */
class PauseLog : Serializable {
    private val intervals = mutableListOf<PauseInterval>()

    fun onPause(elapsedMs: Long) {
        if (intervals.lastOrNull()?.endMs == -1L) return // already paused
        intervals.add(PauseInterval(elapsedMs, -1L))
    }

    fun onResume(elapsedMs: Long) {
        val open = intervals.lastOrNull { it.endMs == -1L } ?: return
        open.endMs = elapsedMs
    }

    fun closeOpenInterval(finalElapsedMs: Long) {
        intervals.lastOrNull { it.endMs == -1L }?.endMs = finalElapsedMs
    }

    /**
     * Maps a point in the camera recording's timeline to the corresponding "virtual"
     * position in the source video's own timeline, accounting for every pause so far.
     * While inside a paused interval, the source video position is frozen at the
     * instant the pause began.
     */
    fun mapToSourceTimeMs(cameraElapsedMs: Long): Long {
        var pausedSoFar = 0L
        for (interval in intervals) {
            if (cameraElapsedMs <= interval.startMs) break
            val effectiveEnd = if (interval.endMs == -1L) cameraElapsedMs else interval.endMs
            if (cameraElapsedMs >= effectiveEnd) {
                pausedSoFar += (interval.endMs - interval.startMs)
            } else {
                // We are currently inside this paused interval: freeze at its start.
                return interval.startMs - pausedSoFar
            }
        }
        return cameraElapsedMs - pausedSoFar
    }

    fun snapshot(): List<PauseInterval> = intervals.toList()
}
