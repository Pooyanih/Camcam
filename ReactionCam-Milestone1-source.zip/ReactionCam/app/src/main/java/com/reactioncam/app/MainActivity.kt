package com.reactioncam.app

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

/**
 * Home screen. Job #1: get a source video Uri with a persistable permission grant,
 * then hand off to RecordActivity. Kept deliberately minimal per the "Select Video ->
 * Record -> Stop -> Finished Video" requirement — no settings, no clutter in v1.
 */
class MainActivity : AppCompatActivity() {

    private var selectedVideoUri: Uri? = null

    private val pickVideoLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) {
                // Persist read permission so RecordActivity / the export pipeline can
                // access this Uri later even after the picker's transient grant would
                // otherwise expire.
                try {
                    contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: SecurityException) {
                    // Some providers don't support persistable grants; the transient
                    // grant is still valid for the lifetime of this task, which is
                    // enough since we immediately move to RecordActivity.
                }
                selectedVideoUri = uri
                findViewById<TextView>(R.id.tvSelectedVideo).apply {
                    text = uri.lastPathSegment ?: uri.toString()
                    visibility = TextView.VISIBLE
                }
                findViewById<Button>(R.id.btnStartRecording).isEnabled = true
            }
        }

    private val permissionsLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
            val cameraOk = grants[android.Manifest.permission.CAMERA] == true
            val micOk = grants[android.Manifest.permission.RECORD_AUDIO] == true
            if (cameraOk && micOk) {
                launchRecordScreen()
            } else {
                Toast.makeText(
                    this,
                    "Camera and microphone permissions are required to record a reaction.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.btnSelectVideo).setOnClickListener {
            pickVideoLauncher.launch(arrayOf("video/*"))
        }

        findViewById<Button>(R.id.btnStartRecording).setOnClickListener {
            requestPermissionsThenLaunch()
        }
    }

    private fun requestPermissionsThenLaunch() {
        val needed = mutableListOf(
            android.Manifest.permission.CAMERA,
            android.Manifest.permission.RECORD_AUDIO
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            needed.add(android.Manifest.permission.POST_NOTIFICATIONS)
        }
        permissionsLauncher.launch(needed.toTypedArray())
    }

    private fun launchRecordScreen() {
        val uri = selectedVideoUri ?: return
        val intent = Intent(this, RecordActivity::class.java).apply {
            putExtra(RecordActivity.EXTRA_SOURCE_VIDEO_URI, uri)
        }
        startActivity(intent)
    }
}
