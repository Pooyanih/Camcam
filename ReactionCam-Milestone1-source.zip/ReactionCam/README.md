# ReactionCam — Milestone 1

A real, working Android app for recording reaction videos with an automatic
picture-in-picture export. No CapCut, no manual editing.

Flow: **Select Video → Record → Stop → Finished Video** (saved to your gallery, ready to share).

## How to build the APK

You need [Android Studio](https://developer.android.com/studio) (free). This project was
written outside of Android Studio (in a sandboxed environment with no Android SDK or
network access), so it has **not** been compiled or run yet — treat the first build as
step one, and see "If the first build doesn't compile" below.

1. Open Android Studio → **Open** → select the `ReactionCam` folder.
2. Let it sync Gradle (downloads dependencies the first time — needs internet).
3. Plug in an Android phone (Android 8.0 / API 26+, so this covers modern Samsung
   devices) with USB debugging on, or use **Build → Generate Signed Bundle / APK**
   to get an installable `.apk` directly.
4. Run it. Grant camera + microphone when asked, pick a video already on your phone,
   hit **Start Recording**.

## What actually happens under the hood (no mocks)

1. **Record screen** — CameraX drives the real front camera and records real camera +
   mic footage to a temp file. The source video autoplays muted in a movable/resizable
   box (drag to move, drag the bottom-right corner handle to resize) on top of the live
   preview. Every Pause/Resume tap is timestamped.
2. **Stop** — the camera recording finalizes.
3. **Export screen** — a GPU compositor (OpenGL + `MediaCodec`, the same class of
   pipeline apps like camera/video editors use) decodes both videos frame by frame,
   draws the camera footage full-screen and the source video into the PiP box you
   positioned, **freezing the PiP layer for exactly the intervals you paused**, and
   encodes one real MP4. Your mic audio (already AAC-encoded by the camera recording)
   is remuxed straight into the final file — no re-encoding, no quality loss.
4. The finished file is inserted into `MediaStore` (Movies/ReactionCam), so it shows up
   in your gallery immediately and is shareable via the normal Android share sheet.

## Known v1 limitations (by design, to ship something complete first)

- The PiP box's position/size is captured **once, at the moment you hit Stop**, and
  used as a single static rect for the whole export. It does not yet animate if you
  moved it mid-recording. (See "Next milestones" — this is a small, isolated change.)
- Only your microphone is recorded; the source video's own audio is muted, on the
  assumption you want a clean reaction track. Easy to make toggleable later.
- Orientation handling (front camera + source video rotation metadata) is implemented
  correctly per the standard Android APIs, but could not be verified on real hardware
  in the environment this was built in (no device/emulator access). If a specific
  Samsung device ever renders sideways or mirrored, the fix is a one-line sign flip in
  `GlUtil.kt`'s `buildTexMatrix` call sites — flag it and it's a quick patch.
- No trimming, captions, or intro screens yet — intentionally deferred, see roadmap.

## Architecture, for future milestones

- `MainActivity` — picker + permissions only.
- `RecordActivity` — live capture: CameraX + ExoPlayer + `PipOverlayView` (drag/resize)
  + `PauseLog` (timestamps).
- `export/` — the entire compositing engine, independent of the UI:
  - `PauseLog.kt` — maps "camera timeline" → "source video virtual timeline",
    handling freezes. This is the one class that encodes the pause/resume rule.
  - `VideoTrackDecoder.kt` — steps one video track forward, frame by frame.
  - `GlUtil.kt` — EGL/shader plumbing; `buildTexMatrix` handles rotation + crop.
  - `VideoCompositor.kt` — orchestrates both decoders + the encoder + the muxer.
- `ExportActivity` — runs `VideoCompositor` on a background thread with a progress
  callback, then saves to `MediaStore` and shows Play/Share.

This split is deliberate so each of these later features is additive, not a rewrite:

| Feature                     | Where it plugs in                                             |
|------------------------------|----------------------------------------------------------------|
| Moving the overlay position  | Replace the single `pipRectNormalized` with a list of timed keyframes; interpolate per-frame in `VideoCompositor`'s render loop. |
| Trimming                     | Change the extractor seek range / start-stop pts fed into the render loop. |
| Captions                     | A third draw call (text rendered to a texture, or a simple canvas overlay bitmap) in the same render loop. |
| Intro screen                 | Render a few seconds of a static/title frame before the main loop starts, same encoder/muxer. |
| Recording settings (quality, camera choice, PiP shape) | Isolated to `RecordActivity`'s CameraX setup and `PipOverlayView`; export code doesn't change. |

## Building without a PC (from your phone) — easiest way, browser only

No Termux, no git, no command line, no token — just GitHub's website in your phone's
browser, three steps.

1. **Create the repo and upload the zip as-is.**
   - Go to github.com on your phone, sign up or log in.
   - Tap **New repository** → give it a name (e.g. `ReactionCam`) → leave it **empty**
     (don't add a README) → **Create repository**.
   - On the new repo's page, tap **Add file → Upload files**, then pick the
     `ReactionCam-Milestone1-source.zip` you downloaded from this chat (from your
     Downloads). Don't unzip it — upload the zip itself. Tap **Commit changes**.
2. **Add the build recipe.**
   - Tap **Add file → Create new file**.
   - In the filename box, type the full path: `.github/workflows/build-apk.yml`
     (typing the slashes creates the folders automatically).
   - Paste in the contents of that same file from the project (open the zip's
     `.github/workflows/build-apk.yml` in any text viewer to copy it, or ask me and
     I'll paste it here for you to copy directly).
   - Tap **Commit changes**.
3. **Get your APK.**
   - Tap the **Actions** tab at the top of your repo. A build should already be
     running (triggered by your commit) — tap it to watch progress, it takes a few
     minutes.
   - When it finishes with a green check, scroll down to **Artifacts** and download
     `ReactionCam-debug-apk` (a small zip containing the `.apk`).
   - Open that zip with your phone's file manager, extract the `.apk`, tap it, allow
     "install unknown apps" if asked. Done.

The workflow automatically detects the uploaded zip and unpacks it before building, so
you never had to extract anything yourself.

## Building without a PC — the Termux/git way (more control, more steps)

You can have GitHub's servers build the APK for you — your phone only needs to push
the code and download the result. This repo already includes the build recipe at
`.github/workflows/build-apk.yml`.

1. **Get the code onto GitHub** (needs a real git client, not just the browser upload
   button, since that can't preserve this project's folder structure):
   - Install **Termux** from F-Droid (not the outdated Play Store version):
     https://f-droid.org/packages/com.termux/
   - In Termux: `pkg install git` then `termux-setup-storage` (grants access to your
     Downloads folder).
   - Extract the zip you downloaded from this chat somewhere in your phone's storage
     (most file manager apps can unzip; if not, `pkg install unzip` in Termux and run
     `unzip ~/storage/downloads/ReactionCam-*.zip -d ~/ReactionCam`).
   - Create a free account at github.com and a new **empty** repository (no README).
   - Create a GitHub Personal Access Token (github.com → Settings → Developer settings
     → Personal access tokens → generate one with "repo" scope) — you'll use it as
     your password when pushing.
   - In Termux:
     ```
     cd ~/ReactionCam        # or wherever you unzipped it
     git init
     git add .
     git commit -m "Initial commit"
     git branch -M main
     git remote add origin https://github.com/<your-username>/<your-repo>.git
     git push -u origin main
     ```
     When prompted for a password, paste the token.
2. **Let GitHub build it**: pushing automatically triggers the workflow. On your
   phone's browser, go to your repo → **Actions** tab → open the running/completed
   workflow → scroll to **Artifacts** → download `ReactionCam-debug-apk` (a small zip
   containing the `.apk`).
3. **Install it**: open the downloaded zip with your phone's file manager, extract the
   `.apk`, tap it, and allow "install unknown apps" for your browser/file manager when
   asked. That's it — no PC involved at any point.

If a future milestone adds new files, the same `git add . && git commit && git push`
three-liner rebuilds it automatically — you don't need to touch the workflow again.


This was authored carefully against the current stable CameraX (1.3.4), Media3 (1.4.1)
and AGP (8.5.2) APIs, but wasn't compiled in this environment (no SDK/network access
there). If Android Studio flags anything, paste the error back and it's a fast, targeted
fix — the architecture above won't need to change.
